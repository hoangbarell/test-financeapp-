import Foundation

public struct Budget: Identifiable, Codable {
    public var id = UUID()
    public var name: String
    public var limit: Int64
    public var category: String? // nil: all spending, repeats monthly
    public init(name: String, limit: Int64, category: String? = nil) { self.name = name; self.limit = limit; self.category = category }
}
public struct EntryTemplate: Identifiable, Codable {
    public var id = UUID()
    public var name: String
    public var kind: EntryKind
    public var amount: Int64
    public var walletID: UUID
    public var category: String
    public var note: String
    public init(name: String, entry: Transaction) { self.name = name; kind = entry.kind; amount = entry.amount; walletID = entry.walletID; category = entry.category; note = entry.note }
    public func draft() -> Transaction { Transaction(kind: kind, amount: amount, walletID: walletID, category: category, note: note) }
}
public enum Cadence: String, Codable, CaseIterable { case once, weekly, monthly, yearly
    public var title: String { switch self { case .once: return "Một lần"; case .weekly: return "Hàng tuần"; case .monthly: return "Hàng tháng"; case .yearly: return "Hàng năm" } }
}
public struct PlannedEntry: Identifiable, Codable {
    public var id = UUID()
    public var name: String
    public var kind: EntryKind
    public var amount: Int64
    public var walletID: UUID
    public var category: String
    public var nextDate: Date
    public var cadence: Cadence
    public var anchorDay: Int
    public var anchorMonth: Int
    public var active = true
    public init(name: String, kind: EntryKind, amount: Int64, walletID: UUID, category: String, nextDate: Date, cadence: Cadence) {
        self.name = name; self.kind = kind; self.amount = amount; self.walletID = walletID; self.category = category; self.nextDate = nextDate; self.cadence = cadence
        anchorDay = Calendar.current.component(.day, from: nextDate); anchorMonth = Calendar.current.component(.month, from: nextDate)
    }
}
public struct SavingGoal: Identifiable, Codable {
    public var id = UUID()
    public var name: String
    public var target: Int64
    public var saved: Int64
    public var date: Date
    public init(name: String, target: Int64, saved: Int64 = 0, date: Date) { self.name = name; self.target = target; self.saved = saved; self.date = date }
}
extension Ledger {
    enum CodingKeys: String, CodingKey { case version, wallets, transactions, budgets, templates, plans, goals }
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        version = try c.decode(Int.self, forKey: .version)
        wallets = try c.decode([Wallet].self, forKey: .wallets)
        transactions = try c.decode([Transaction].self, forKey: .transactions)
        budgets = try c.decodeIfPresent([Budget].self, forKey: .budgets) ?? []
        templates = try c.decodeIfPresent([EntryTemplate].self, forKey: .templates) ?? []
        plans = try c.decodeIfPresent([PlannedEntry].self, forKey: .plans) ?? []
        goals = try c.decodeIfPresent([SavingGoal].self, forKey: .goals) ?? []
    }
    public func netExpense(in interval: DateInterval? = nil, category: String? = nil) -> Int64 {
        transactions.reduce(Int64(0)) { result, e in
            guard category == nil || e.category == category, interval == nil || (e.date >= interval!.start && e.date < interval!.end) else { return result }
            return result + (e.kind == .expense ? e.amount : e.kind == .refund ? -e.amount : 0)
        }
    }
    public mutating func confirmPlan(_ id: UUID, on date: Date? = nil, calendar: Calendar = .current) throws {
        guard let i = plans.firstIndex(where: { $0.id == id }), plans[i].active else { throw LedgerError.invalid("Khoản này đã hoàn tất.") }
        let p = plans[i]; let now = date ?? Date()
        guard calendar.startOfDay(for: p.nextDate) <= calendar.startOfDay(for: now) else { throw LedgerError.invalid("Chưa đến hạn. Bạn có thể ghi thủ công nếu thanh toán sớm.") }
        transactions.append(Transaction(kind: p.kind, amount: p.amount, walletID: p.walletID, category: p.category, note: p.name, date: p.nextDate, relatedID: p.id))
        if p.cadence == .once { plans[i].active = false; return }
        if p.cadence == .weekly { plans[i].nextDate = calendar.date(byAdding: .day, value: 7, to: p.nextDate)!; return }
        let component: Calendar.Component = p.cadence == .monthly ? .month : .year
        let base = calendar.dateInterval(of: component, for: p.nextDate)!.start
        let next = calendar.date(byAdding: component, value: 1, to: base)!
        var c = calendar.dateComponents([.year, .month], from: next)
        if p.cadence == .yearly { c.month = p.anchorMonth }
        let first = calendar.date(from: c)!
        c.day = min(p.anchorDay, calendar.range(of: .day, in: .month, for: first)!.count)
        let time = calendar.dateComponents([.hour, .minute], from: p.nextDate); c.hour = time.hour; c.minute = time.minute
        plans[i].nextDate = calendar.date(from: c)!
    }
    func validatePlanning() throws {
        let limit: Int64 = 1_000_000_000_000_000
        let walletIDs = Set(wallets.map(\.id))
        let allIDs = budgets.map(\.id) + templates.map(\.id) + plans.map(\.id) + goals.map(\.id)
        guard allIDs.count <= 4000, Set(allIDs).count == allIDs.count,
              budgets.allSatisfy({ !$0.name.isEmpty && $0.limit > 0 && $0.limit <= limit }),
              templates.allSatisfy({ [.income, .expense].contains($0.kind) && $0.amount > 0 && $0.amount <= limit && walletIDs.contains($0.walletID) }),
              plans.allSatisfy({ [.income, .expense].contains($0.kind) && $0.amount > 0 && $0.amount <= limit && walletIDs.contains($0.walletID) && $0.nextDate.timeIntervalSince1970.isFinite && (1...31).contains($0.anchorDay) && (1...12).contains($0.anchorMonth) }),
              goals.allSatisfy({ !$0.name.isEmpty && $0.target > 0 && $0.target <= limit && $0.saved >= 0 && $0.saved <= limit && $0.date.timeIntervalSince1970.isFinite }) else { throw LedgerError.invalid("Ngân sách, mẫu, khoản định kỳ hoặc mục tiêu không hợp lệ.") }
        var refunded: [UUID: Int64] = [:]
        for e in transactions where e.kind == .refund {
            guard let id = e.relatedID, let purchase = transactions.first(where: { $0.id == id && $0.kind == .expense }), e.category == purchase.category else { throw LedgerError.invalid("Hoàn trả cần liên kết với khoản chi gốc và cùng danh mục.") }
            refunded[id, default: 0] += e.amount
            guard refunded[id]! <= purchase.amount else { throw LedgerError.invalid("Tiền hoàn vượt khoản chi gốc.") }
        }
    }
}
extension Transaction {
    public func split(_ parts: [(category: String, amount: Int64)]) throws -> [Transaction] {
        guard kind == .expense, parts.count >= 2, parts.count <= 100, parts.allSatisfy({ $0.amount > 0 && $0.amount <= amount && !$0.category.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) else { throw LedgerError.invalid("Chia khoản chi thành ít nhất hai danh mục hợp lệ.") }
        var sum: Int64 = 0
        for part in parts { let (next, overflow) = sum.addingReportingOverflow(part.amount); guard !overflow else { throw LedgerError.invalid("Số tiền quá lớn.") }; sum = next }
        guard sum == amount else { throw LedgerError.invalid("Tổng các phần phải bằng khoản chi gốc.") }
        let group = groupID ?? UUID()
        return parts.map { Transaction(kind: .expense, amount: $0.amount, walletID: walletID, category: $0.category, note: note, date: date, groupID: group) }
    }
}

public struct QuickEntry {
    public var amount: Int64
    public var kind: EntryKind
    public var category: String
    public var note: String
    public static func amount(_ input: String) throws -> Int64 {
        var s = input.lowercased().trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "₫", with: "").replacingOccurrences(of: "vnd", with: "").trimmingCharacters(in: .whitespaces)
        var multiplier: Int64 = 1
        for (suffix, value) in [("triệu", Int64(1_000_000)), ("nghìn", 1_000), ("ngàn", 1_000), ("tr", 1_000_000), ("k", 1_000)] {
            if s.hasSuffix(suffix) { multiplier = value; s = String(s.dropLast(suffix.count)).trimmingCharacters(in: .whitespaces); break }
        }
        if multiplier == 1 {
            guard s.range(of: "^[0-9]+$|^[0-9]{1,3}([., ][0-9]{3})+$", options: .regularExpression) != nil else { throw LedgerError.invalid("Nhập số nguyên VND, ví dụ 35k hoặc 1.500.000.") }
            s = s.filter(\.isNumber)
        } else {
            guard s.range(of: "^[0-9]+([.,][0-9]{1,3})?$", options: .regularExpression) != nil else { throw LedgerError.invalid("Số tiền viết tắt không rõ.") }
            s = s.replacingOccurrences(of: ",", with: ".")
        }
        guard let decimal = Decimal(string: s, locale: Locale(identifier: "en_US_POSIX")) else { throw LedgerError.invalid("Số tiền không hợp lệ.") }
        let value = decimal * Decimal(multiplier)
        guard value > 0, value <= Decimal(1_000_000_000_000_000 as Int64), Decimal(NSDecimalNumber(decimal: value).int64Value) == value else { throw LedgerError.invalid("Nhập số tiền nguyên dương trong giới hạn.") }
        return NSDecimalNumber(decimal: value).int64Value
    }
    public static func parse(_ text: String) throws -> QuickEntry {
        let regex = try NSRegularExpression(pattern: "[+-]?[0-9]+(?:[.,][0-9]+)*(?:\\s*(?:triệu|nghìn|ngàn|tr|k|vnd|₫))?", options: .caseInsensitive)
        let ns = text as NSString
        let matches = regex.matches(in: text, range: NSRange(location: 0, length: ns.length))
        guard matches.count == 1, let match = matches.first else { throw LedgerError.invalid("Cần đúng một số tiền. Hãy bỏ ngày/số khác hoặc nhập thủ công.") }
        let value = try amount(ns.substring(with: match.range))
        let note = ns.replacingCharacters(in: match.range, with: "").trimmingCharacters(in: .whitespacesAndNewlines)
        let lower = note.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "vi_VN"))
        let income = ["luong", "thu nhap", "nhan tien", "thuong"].contains { lower.contains($0) }
        var category = income ? "Lương" : "Khác"
        let rules = [("Ăn uống", ["ca phe", "cafe", "an ", "com", "tra sua", "banh"]), ("Di chuyển", ["taxi", "grab", "xang", "xe"]), ("Nhà ở", ["tien nha", "tien dien", "tien nuoc"]), ("Mua sắm", ["mua", "shopping"]), ("Sức khỏe", ["thuoc", "kham"])]
        if !income { for rule in rules where rule.1.contains(where: { lower.contains($0) }) { category = rule.0; break } }
        return QuickEntry(amount: value, kind: income ? .income : .expense, category: category, note: note)
    }
}

public enum CSVTable {
    public static func parse(_ input: String, delimiter: Character = ",") throws -> [[String]] {
        let text = input.replacingOccurrences(of: "\u{FEFF}", with: "").replacingOccurrences(of: "\r\n", with: "\n").replacingOccurrences(of: "\r", with: "\n")
        var rows: [[String]] = []; var row: [String] = []; var field = ""; var quoted = false; var afterQuote = false
        let chars = Array(text); var i = 0
        while i < chars.count {
            let c = chars[i]
            if quoted {
                if c == "\"" { if i + 1 < chars.count && chars[i + 1] == "\"" { field.append("\""); i += 1 } else { quoted = false; afterQuote = true } }
                else { field.append(c) }
            } else if c == delimiter { row.append(field); field = ""; afterQuote = false }
            else if c == "\n" { row.append(field); if row.contains(where: { !$0.isEmpty }) { rows.append(row) }; row = []; field = ""; afterQuote = false }
            else if c == "\"" && field.isEmpty && !afterQuote { quoted = true }
            else { guard !afterQuote else { throw LedgerError.invalid("CSV có ký tự sau dấu đóng ngoặc kép.") }; field.append(c) }
            i += 1
        }
        guard !quoted else { throw LedgerError.invalid("CSV thiếu dấu đóng ngoặc kép.") }
        row.append(field); if row.contains(where: { !$0.isEmpty }) { rows.append(row) }
        guard rows.count <= 100_001 else { throw LedgerError.invalid("CSV quá nhiều dòng.") }
        return rows
    }
}
