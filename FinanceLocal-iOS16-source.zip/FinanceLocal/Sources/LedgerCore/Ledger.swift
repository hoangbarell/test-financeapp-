import Foundation

public enum EntryKind: String, Codable, CaseIterable, Identifiable {
    case income, expense, transfer, refund, adjustment
    public var id: String { rawValue }
    public var title: String {
        switch self { case .income: return "Thu nhập"; case .expense: return "Chi tiêu"; case .transfer: return "Chuyển ví"; case .refund: return "Hoàn trả"; case .adjustment: return "Điều chỉnh" }
    }
}

public struct Wallet: Identifiable, Codable, Equatable {
    public var id: UUID
    public var name: String
    public var openingBalance: Int64
    public init(id: UUID = UUID(), name: String, openingBalance: Int64) {
        self.id = id; self.name = name; self.openingBalance = openingBalance
    }
}

public struct Transaction: Identifiable, Codable, Equatable {
    public var id: UUID
    public var kind: EntryKind
    public var amount: Int64
    public var walletID: UUID
    public var destinationID: UUID?
    public var category: String
    public var note: String
    public var date: Date
    public var relatedID: UUID?
    public var groupID: UUID?
    public init(id: UUID = UUID(), kind: EntryKind, amount: Int64, walletID: UUID, destinationID: UUID? = nil, category: String = "Khác", note: String = "", date: Date = Date(), relatedID: UUID? = nil, groupID: UUID? = nil) {
        self.id = id; self.kind = kind; self.amount = amount; self.walletID = walletID
        self.destinationID = destinationID; self.category = category; self.note = note; self.date = date
        self.relatedID = relatedID; self.groupID = groupID
    }
}

public struct Ledger: Codable {
    public var version = 1
    public var wallets: [Wallet]
    public var transactions: [Transaction]
    public var budgets: [Budget] = []
    public var templates: [EntryTemplate] = []
    public var plans: [PlannedEntry] = []
    public var goals: [SavingGoal] = []
    public init(wallets: [Wallet] = [], transactions: [Transaction] = []) {
        self.wallets = wallets; self.transactions = transactions
    }
    public func balance(_ id: UUID) -> Int64 {
        transactions.reduce(wallets.first(where: { $0.id == id })?.openingBalance ?? 0) { result, entry in
            if entry.walletID == id { return result + ([EntryKind.income, .refund, .adjustment].contains(entry.kind) ? entry.amount : -entry.amount) }
            if entry.kind == .transfer && entry.destinationID == id { return result + entry.amount }
            return result
        }
    }
    public func total(_ kind: EntryKind, in interval: DateInterval? = nil) -> Int64 {
        transactions.filter { entry in
            entry.kind == kind && (interval.map { $0.start <= entry.date && entry.date < $0.end } ?? true)
        }.reduce(0) { $0 + $1.amount }
    }
    public func validate() throws {
        guard version == 1 else { throw LedgerError.invalid("Phiên bản sao lưu chưa được hỗ trợ.") }
        let ids = Set(wallets.map(\.id))
        guard ids.count == wallets.count, Set(transactions.map(\.id)).count == transactions.count else { throw LedgerError.invalid("Dữ liệu chứa ID trùng lặp.") }
        let limit: Int64 = 1_000_000_000_000_000
        guard wallets.allSatisfy({ !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && $0.openingBalance >= -limit && $0.openingBalance <= limit }), transactions.count <= 100_000, wallets.count <= 1_000 else { throw LedgerError.invalid("Tên ví hoặc giới hạn dữ liệu không hợp lệ.") }
        for entry in transactions {
            guard entry.amount >= -limit, entry.amount <= limit, entry.amount != 0, (entry.kind == .adjustment || entry.amount > 0), ids.contains(entry.walletID), entry.date.timeIntervalSince1970.isFinite else { throw LedgerError.invalid("Giao dịch không hợp lệ.") }
            if entry.kind == .transfer {
                guard let destination = entry.destinationID, destination != entry.walletID, ids.contains(destination) else { throw LedgerError.invalid("Hãy chọn hai ví khác nhau.") }
            } else if entry.destinationID != nil { throw LedgerError.invalid("Giao dịch thu/chi không có ví nhận.") }
        }
        // Bound cumulative values before arithmetic so malformed imports cannot overflow.
        var magnitude: Int64 = 0
        for wallet in wallets { let (value, overflow) = magnitude.addingReportingOverflow(abs(wallet.openingBalance)); guard !overflow else { throw LedgerError.invalid("Số dư quá lớn.") }; magnitude = value }
        for entry in transactions { let (value, overflow) = magnitude.addingReportingOverflow(abs(entry.amount)); guard !overflow, value <= Int64.max / 2 else { throw LedgerError.invalid("Tổng giao dịch quá lớn.") }; magnitude = value }
        try validatePlanning()
    }
}

public enum LedgerError: LocalizedError {
    case invalid(String)
    public var errorDescription: String? { if case .invalid(let message) = self { return message }; return nil }
}
