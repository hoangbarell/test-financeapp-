import XCTest
@testable import LedgerCore

final class UpgradeTests: XCTestCase {
    func testVietnameseAmountsAndAmbiguity() throws {
        XCTAssertEqual(try QuickEntry.parse("cà phê 35k").amount, 35_000)
        XCTAssertEqual(try QuickEntry.parse("nhận lương 1,5tr").amount, 1_500_000)
        XCTAssertEqual(try QuickEntry.parse("ăn trưa 1.500.000").amount, 1_500_000)
        XCTAssertThrowsError(try QuickEntry.parse("ăn 35k taxi 20k"))
        XCTAssertThrowsError(try QuickEntry.parse("ăn 12/10 35k"))
        XCTAssertThrowsError(try QuickEntry.parse("cà phê"))
        XCTAssertThrowsError(try QuickEntry.parse("ăn -35k"))
    }
    func testLegacyBackupAndPlanningRoundTrip() throws {
        let old = Data("{\"version\":1,\"wallets\":[],\"transactions\":[]}".utf8)
        var ledger = try JSONDecoder().decode(Ledger.self, from: old)
        XCTAssertTrue(ledger.budgets.isEmpty)
        ledger.budgets = [Budget(name: "Ăn uống", limit: 1_000_000, category: "Ăn uống")]
        let restored = try JSONDecoder().decode(Ledger.self, from: JSONEncoder().encode(ledger))
        XCTAssertEqual(restored.budgets.first?.limit, 1_000_000)
        try restored.validate()
    }
    func testRefundAndAdjustmentDoNotInflateIncome() throws {
        let w = Wallet(name: "Ví", openingBalance: 1_000)
        let e = Transaction(kind: .expense, amount: 500, walletID: w.id, category: "Mua sắm")
        var ledger = Ledger(wallets: [w], transactions: [e])
        ledger.transactions.append(Transaction(kind: .refund, amount: 200, walletID: w.id, category: e.category, relatedID: e.id))
        ledger.transactions.append(Transaction(kind: .adjustment, amount: -100, walletID: w.id, note: "Đối chiếu"))
        try ledger.validate()
        XCTAssertEqual(ledger.balance(w.id), 600)
        XCTAssertEqual(ledger.total(.income), 0)
        XCTAssertEqual(ledger.netExpense(), 300)
    }
    func testRecurringConfirmationAndMonthEnd() throws {
        let w = Wallet(name: "Ví", openingBalance: 0)
        var calendar = Calendar(identifier: .gregorian); calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        let jan = calendar.date(from: DateComponents(year: 2026, month: 1, day: 31))!
        let plan = PlannedEntry(name: "Nhà", kind: .expense, amount: 100, walletID: w.id, category: "Nhà ở", nextDate: jan, cadence: .monthly)
        var ledger = Ledger(wallets: [w]); ledger.plans = [plan]
        try ledger.confirmPlan(plan.id, calendar: calendar)
        XCTAssertEqual(ledger.transactions.count, 1)
        XCTAssertEqual(calendar.component(.day, from: ledger.plans[0].nextDate), 28)
        XCTAssertThrowsError(try ledger.confirmPlan(plan.id, on: jan, calendar: calendar))
        try ledger.validate()
    }
    func testCSVQuotesAndInvalidInput() throws {
        let rows = try CSVTable.parse("date,amount,note\r\n2026-10-12,35000,\"cà phê, bánh\"\r\n2026-10-13,40000,\"hai\"\" chữ\"")
        XCTAssertEqual(rows[1][2], "cà phê, bánh")
        XCTAssertEqual(rows[2][2], "hai\" chữ")
        XCTAssertThrowsError(try CSVTable.parse("a,b\n\"unfinished"))
    }
    func testSplitMustMatchAndRefundMustNotExceedPurchase() throws {
        let w = Wallet(name: "Ví", openingBalance: 0)
        let e = Transaction(kind: .expense, amount: 100, walletID: w.id)
        XCTAssertEqual(try e.split([(category: "Ăn uống", amount: 60), (category: "Khác", amount: 40)]).reduce(0) { $0 + $1.amount }, 100)
        XCTAssertThrowsError(try e.split([(category: "Khác", amount: 99)]))
        let refund = Transaction(kind: .refund, amount: 101, walletID: w.id, category: e.category, relatedID: e.id)
        XCTAssertThrowsError(try Ledger(wallets: [w], transactions: [e, refund]).validate())
    }
}
