import XCTest
@testable import LedgerCore

final class LedgerTests: XCTestCase {
    func testMonthlyTotalsExcludeNextMonthBoundary() {
        let wallet = Wallet(name: "Ví", openingBalance: 0)
        let start = Date(timeIntervalSince1970: 1_000)
        let end = Date(timeIntervalSince1970: 2_000)
        let ledger = Ledger(wallets: [wallet], transactions: [
            Transaction(kind: .income, amount: 100, walletID: wallet.id, date: start),
            Transaction(kind: .income, amount: 200, walletID: wallet.id, date: end)
        ])
        XCTAssertEqual(ledger.total(.income, in: DateInterval(start: start, end: end)), 100)
    }
    func testTransferChangesWalletBalancesButNotIncomeOrExpense() throws {
        let a = Wallet(name: "Tiền mặt", openingBalance: 1_000_000)
        let b = Wallet(name: "Ngân hàng", openingBalance: 0)
        let transfer = Transaction(kind: .transfer, amount: 200_000, walletID: a.id, destinationID: b.id)
        let ledger = Ledger(wallets: [a, b], transactions: [transfer])
        try ledger.validate()
        XCTAssertEqual(ledger.balance(a.id), 800_000)
        XCTAssertEqual(ledger.balance(b.id), 200_000)
        XCTAssertEqual(ledger.total(.income), 0)
        XCTAssertEqual(ledger.total(.expense), 0)
    }

    func testBackupRoundTripPreservesIDsAndBalances() throws {
        let wallet = Wallet(name: "Ví", openingBalance: 500)
        let original = Ledger(wallets: [wallet], transactions: [Transaction(kind: .expense, amount: 100, walletID: wallet.id)])
        let restored = try JSONDecoder().decode(Ledger.self, from: JSONEncoder().encode(original))
        try restored.validate()
        XCTAssertEqual(restored.wallets.first?.id, wallet.id)
        XCTAssertEqual(restored.balance(wallet.id), 400)
    }

    func testRejectsInvalidTransferAndNegativeAmount() {
        let wallet = Wallet(name: "Ví", openingBalance: 0)
        for entry in [Transaction(kind: .transfer, amount: 100, walletID: wallet.id, destinationID: wallet.id), Transaction(kind: .expense, amount: -1, walletID: wallet.id)] {
            XCTAssertThrowsError(try Ledger(wallets: [wallet], transactions: [entry]).validate())
        }
    }

    func testRejectsDuplicateIDsAndUnsupportedBackup() {
        let wallet = Wallet(name: "Ví", openingBalance: 0)
        XCTAssertThrowsError(try Ledger(wallets: [wallet, wallet]).validate())
        var ledger = Ledger(wallets: [wallet])
        ledger.version = 999
        XCTAssertThrowsError(try ledger.validate())
    }

    func testDeletingTransactionRestoresBalance() {
        let wallet = Wallet(name: "Ví", openingBalance: 1_000)
        var ledger = Ledger(wallets: [wallet], transactions: [Transaction(kind: .income, amount: 500, walletID: wallet.id)])
        XCTAssertEqual(ledger.balance(wallet.id), 1_500)
        ledger.transactions.removeAll()
        XCTAssertEqual(ledger.balance(wallet.id), 1_000)
    }
}
