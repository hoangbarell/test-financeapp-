import SwiftUI
import UniformTypeIdentifiers

struct ImportRow: Identifiable {
    let id: Int
    let entry: Transaction?
    let issue: String?
    let duplicate: Bool
}
struct CSVImportView: View {
    @EnvironmentObject var store: Store
    @State private var importing = false
    @State private var table: [[String]] = []
    @State private var dateColumn = 0
    @State private var amountColumn = 2
    @State private var categoryColumn = -1
    @State private var noteColumn = -1
    @State private var kindColumn = -1
    @State private var dateFormat = "yyyy-MM-dd"
    @State private var wallet: UUID?
    @State private var separator = ","
    @State private var raw = ""
    @State private var rows: [ImportRow] = []
    @State private var selected = Set<Int>()
    @State private var confirming = false
    @State private var message = ""
    private var headers: [String] { table.first ?? [] }
    var body: some View {
        Form {
            Section("1 · Chọn file và ví nhận") {
                Button("Chọn CSV UTF-8") { importing = true }
                Picker("Dấu phân cách", selection: $separator) { Text("Dấu phẩy").tag(","); Text("Chấm phẩy").tag(";"); Text("Tab").tag("\t") }
                Picker("Nhập vào ví", selection: $wallet) { ForEach(store.ledger.wallets) { Text($0.name).tag(Optional($0.id)) } }
                Text("CSV dành cho thu/chi. Chuyển ví, hoàn trả, điều chỉnh và đầy đủ kế hoạch dùng backup JSON để giữ đúng liên kết.").font(.caption).foregroundStyle(.secondary)
            }
            if !headers.isEmpty { mappingSection }
            if !rows.isEmpty { previewSection }
            if !message.isEmpty { Text(message).font(.caption).foregroundStyle(.secondary) }
        }.navigationTitle("Nhập CSV").onAppear { wallet = store.ledger.wallets.first?.id }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.commaSeparatedText, .plainText]) { result in read(result) }
            .onChange(of: separator) { _ in parseTable() }
            .onChange(of: dateColumn) { _ in clearPreview() }.onChange(of: amountColumn) { _ in clearPreview() }
            .onChange(of: categoryColumn) { _ in clearPreview() }.onChange(of: noteColumn) { _ in clearPreview() }
            .onChange(of: kindColumn) { _ in clearPreview() }.onChange(of: wallet) { _ in clearPreview() }
            .onChange(of: dateFormat) { _ in clearPreview() }
            .confirmationDialog("Nhập \(selected.count) giao dịch đã chọn?", isPresented: $confirming, titleVisibility: .visible) {
                Button("Nhập và lưu backup nội bộ") { commit() }
            } message: { Text("Các dòng nghi trùng mặc định bỏ chọn. Bạn có thể chọn lại nếu đó là khoản khác. Có thể hoàn tác ngay sau nhập.") }
    }
    private var mappingSection: some View {
        Section("2 · Chọn cột · dòng đầu là tiêu đề") {
            column("Ngày", selection: $dateColumn, optional: false)
            column("Số tiền", selection: $amountColumn, optional: false)
            column("Loại", selection: $kindColumn, optional: true)
            column("Danh mục", selection: $categoryColumn, optional: true)
            column("Ghi chú", selection: $noteColumn, optional: true)
            Picker("Định dạng ngày", selection: $dateFormat) {
                Text("2026-10-12").tag("yyyy-MM-dd")
                Text("12/10/2026").tag("dd/MM/yyyy")
                Text("ISO 8601 (CSV Nhím)").tag("ISO")
            }
            Text("Không chọn loại: số âm là chi, số dương là thu. Có cột loại: chấp nhận Thu nhập/Chi tiêu hoặc income/expense. Số VND nguyên, dấu phân nhóm theo dạng 1.500.000 hoặc 1,500,000.").font(.caption).foregroundStyle(.secondary)
            Button("Kiểm tra và xem trước \(max(0, table.count - 1)) dòng") { preview() }
        }
    }
    private var previewSection: some View {
        Section("3 · Xem trước · \(selected.count) dòng được chọn") {
            ForEach(rows) { row in
                if let entry = row.entry {
                    Toggle(isOn: Binding(get: { selected.contains(row.id) }, set: { value in if value { selected.insert(row.id) } else { selected.remove(row.id) } })) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Dòng \(row.id + 1) · \(entry.kind.title) · \(money(entry.amount))").font(.subheadline)
                            Text("\(entry.date.formatted(date: .abbreviated, time: .omitted)) · \(entry.category) · \(entry.note)").font(.caption)
                            if row.duplicate { Text("Có thể trùng với dữ liệu đã có hoặc dòng trước").font(.caption).foregroundStyle(Palette.negative) }
                        }
                    }
                } else { Text("Dòng \(row.id + 1): \(row.issue ?? "Không hợp lệ")").font(.caption).foregroundStyle(Palette.negative) }
            }
            Button("Nhập \(selected.count) giao dịch") { confirming = true }.disabled(selected.isEmpty || !store.ready)
        }
    }
    private func column(_ title: String, selection: Binding<Int>, optional: Bool) -> some View {
        Picker(title, selection: selection) {
            if optional { Text("Không dùng").tag(-1) }
            ForEach(Array(headers.enumerated()), id: \.offset) { i, name in Text("\(i + 1): \(name)").tag(i) }
        }
    }
    private func clearPreview() { rows = []; selected = [] }
    private func read(_ result: Result<URL, Error>) {
        do {
            let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
            guard (try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0) <= 5_000_000 else { throw LedgerError.invalid("CSV tối đa 5 MB.") }
            raw = try String(contentsOf: url, encoding: .utf8); parseTable()
        } catch { store.error = error.localizedDescription }
    }
    private func parseTable() {
        guard !raw.isEmpty else { return }
        do {
            table = try CSVTable.parse(raw, delimiter: separator.first ?? ","); clearPreview()
            guard table.count <= 10_001, headers.count >= 2 else { table = []; throw LedgerError.invalid("Cần ít nhất hai cột, tối đa 10.000 giao dịch mỗi đợt.") }
            dateColumn = 0; amountColumn = min(2, headers.count - 1); categoryColumn = headers.firstIndex(of: "Danh mục") ?? -1; noteColumn = headers.firstIndex(of: "Ghi chú") ?? -1; kindColumn = headers.firstIndex(of: "Loại") ?? -1
            if headers.first == "Ngày" { dateFormat = "ISO" }
            message = "Đã đọc CSV. Kiểm tra cột trước khi nhập."
        } catch { store.error = error.localizedDescription }
    }
    private func field(_ row: [String], _ index: Int) -> String { row.indices.contains(index) ? row[index].trimmingCharacters(in: .whitespacesAndNewlines) : "" }
    private func preview() {
        guard let wallet else { return }; var result: [ImportRow] = []; var seen = store.ledger.transactions
        for (offset, row) in table.dropFirst().enumerated() {
            do {
                let dateText = field(row, dateColumn); let date: Date?
                if dateFormat == "ISO" { date = ISO8601DateFormatter().date(from: dateText) }
                else { let formatter = DateFormatter(); formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.dateFormat = dateFormat; formatter.isLenient = false; date = formatter.date(from: dateText) }
                guard let date else { throw LedgerError.invalid("Ngày không đúng định dạng đã chọn.") }
                let number = field(row, amountColumn); let negative = number.hasPrefix("-")
                let amount = try QuickEntry.amount(negative ? String(number.dropFirst()) : number)
                let type = field(row, kindColumn).lowercased(); let kind: EntryKind
                if kindColumn < 0 { kind = negative ? .expense : .income }
                else if ["thu nhập", "income"].contains(type) { kind = .income }
                else if ["chi tiêu", "expense"].contains(type) { kind = .expense }
                else { throw LedgerError.invalid("Chỉ nhập thu/chi; dùng JSON cho các loại khác.") }
                let category = field(row, categoryColumn)
                let entry = Transaction(kind: kind, amount: amount, walletID: wallet, category: category.isEmpty ? "Khác" : category, note: field(row, noteColumn), date: date)
                let duplicate = seen.contains { $0.walletID == wallet && $0.kind == kind && $0.amount == amount && Calendar.current.isDate($0.date, inSameDayAs: date) && $0.note == entry.note }
                result.append(ImportRow(id: offset + 1, entry: entry, issue: nil, duplicate: duplicate)); seen.append(entry)
            } catch { result.append(ImportRow(id: offset + 1, entry: nil, issue: error.localizedDescription, duplicate: false)) }
        }
        rows = result; selected = Set(result.filter { $0.entry != nil && !$0.duplicate }.map(\.id))
    }
    private func commit() {
        do {
            try store.checkpoint(force: true)
            let entries = rows.filter { selected.contains($0.id) }.compactMap(\.entry)
            if store.update({ $0.transactions.append(contentsOf: entries) }) { message = "Đã nhập \(entries.count) giao dịch. Nút Hoàn tác nằm ở thanh thông báo dưới cùng."; clearPreview() }
        } catch { store.error = error.localizedDescription }
    }
}
