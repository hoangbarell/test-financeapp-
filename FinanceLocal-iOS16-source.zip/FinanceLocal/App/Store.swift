import SwiftUI
import UniformTypeIdentifiers
import UserNotifications

@MainActor final class Store: ObservableObject {
    @Published private(set) var ledger = Ledger()
    @Published var error: String?
    @Published private(set) var ready = false
    @Published var undoLedger: Ledger?
    @Published var toast: String?
    private let url: URL
    init() {
        url = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("ledger.json")
        #if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--preview-sample") {
            let cash = Wallet(name: "Tiền mặt", openingBalance: 500_000)
            let bank = Wallet(name: "Ngân hàng", openingBalance: 2_000_000)
            let now = Date()
            ledger = Ledger(wallets: [cash, bank], transactions: [
                Transaction(kind: .income, amount: 12_000_000, walletID: bank.id, category: "Lương", note: "Lương tháng này", date: now),
                Transaction(kind: .expense, amount: 450_000, walletID: cash.id, category: "Ăn uống", note: "Ăn trưa & cà phê", date: now),
                Transaction(kind: .expense, amount: 250_000, walletID: bank.id, category: "Di chuyển", note: "Đi lại trong tuần", date: now),
                Transaction(kind: .expense, amount: 800_000, walletID: bank.id, category: "Mua sắm", note: "Một món đồ mới", date: now),
                Transaction(kind: .expense, amount: 3_000_000, walletID: bank.id, category: "Nhà ở", note: "Tiền nhà", date: now)
            ])
            ledger.budgets = [Budget(name: "Ngân sách tháng", limit: 7_000_000), Budget(name: "Ăn uống", limit: 1_500_000, category: "Ăn uống")]
            ledger.templates = [EntryTemplate(name: "Cà phê sáng", entry: Transaction(kind: .expense, amount: 35_000, walletID: cash.id, category: "Ăn uống", note: "Cà phê sáng"))]
            ledger.plans = [PlannedEntry(name: "Tiền điện", kind: .expense, amount: 450_000, walletID: bank.id, category: "Nhà ở", nextDate: now, cadence: .monthly)]
            ledger.goals = [SavingGoal(name: "Quỹ dự phòng", target: 20_000_000, saved: 5_000_000, date: Calendar.current.date(byAdding: .month, value: 6, to: now)!)]
            ready = true
            return
        }
        #endif
        do {
            if FileManager.default.fileExists(atPath: url.path) {
                let value = try JSONDecoder().decode(Ledger.self, from: Data(contentsOf: url))
                try value.validate(); ledger = value
            } else {
                let value = Ledger(wallets: [Wallet(name: "Tiền mặt", openingBalance: 0)])
                try persist(value); ledger = value
            }
            ready = true
        } catch { self.error = "Không thể đọc dữ liệu. File gốc được giữ nguyên. \(error.localizedDescription)" }
    }
    private func persist(_ value: Ledger) throws {
        try value.validate()
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(value).write(to: url, options: [.atomic, .completeFileProtection])
    }
    @discardableResult func update(_ change: (inout Ledger) -> Void) -> Bool {
        guard ready else { error = "Hãy khôi phục bản sao lưu trước khi tiếp tục."; return false }
        var next = ledger; change(&next)
        do { try checkpoint(); try persist(next); undoLedger = ledger; ledger = next; toast = "Đã lưu thay đổi"; scheduleReminders(); return true }
        catch { self.error = error.localizedDescription; return false }
    }
    func undo() {
        guard let previous = undoLedger else { return }
        do { try persist(previous); ledger = previous; undoLedger = nil; toast = nil; scheduleReminders() }
        catch { self.error = error.localizedDescription }
    }
    func checkpoint(force: Bool = false) throws {
        guard FileManager.default.fileExists(atPath: url.path) else { return }
        let folder = url.deletingLastPathComponent().appendingPathComponent("Backups", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let day = Date().formatted(.iso8601.year().month().day().dateSeparator(.dash))
        let name = force ? "before-change-\(UUID().uuidString).json" : "daily-\(day).json"
        let destination = folder.appendingPathComponent(name)
        if !FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.copyItem(at: url, to: destination) }
        let files = try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.creationDateKey]).sorted { left, right in
            let a = (try? left.resourceValues(forKeys: [.creationDateKey]).creationDate) ?? .distantPast
            let b = (try? right.resourceValues(forKeys: [.creationDateKey]).creationDate) ?? .distantPast
            return a > b
        }
        for file in files.dropFirst(20) { try FileManager.default.removeItem(at: file) }
    }
    func localBackups() -> [URL] {
        let folder = url.deletingLastPathComponent().appendingPathComponent("Backups")
        return ((try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.creationDateKey])) ?? []).sorted { $0.lastPathComponent > $1.lastPathComponent }
    }
    func confirm(_ plan: PlannedEntry) {
        var next = ledger
        do { try next.confirmPlan(plan.id); _ = update { $0 = next } }
        catch { self.error = error.localizedDescription }
    }
    func scheduleReminders() {
        guard UserDefaults.standard.bool(forKey: "billReminders") else { return }
        let center = UNUserNotificationCenter.current()
        center.removeAllPendingNotificationRequests()
        for plan in ledger.plans.filter({ $0.active && $0.nextDate > Date() }).sorted(by: { $0.nextDate < $1.nextDate }).prefix(50) {
            let content = UNMutableNotificationContent(); content.title = "Nhím Money · Khoản đến hạn"; content.body = "Bạn có khoản dự kiến cần kiểm tra trong app."; content.sound = .default
            let components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: plan.nextDate)
            let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
            center.add(UNNotificationRequest(identifier: plan.id.uuidString, content: content, trigger: trigger))
        }
    }
    func restore(_ data: Data) throws {
        guard data.count <= 25_000_000 else { throw LedgerError.invalid("File sao lưu vượt quá 25 MB.") }
        let next = try JSONDecoder().decode(Ledger.self, from: data)
        try next.validate()
        if FileManager.default.fileExists(atPath: url.path) {
            let backup = url.deletingLastPathComponent().appendingPathComponent("before-restore-\(UUID().uuidString).json")
            try FileManager.default.copyItem(at: url, to: backup)
        }
        try persist(next); ledger = next; ready = true; undoLedger = nil; scheduleReminders()
    }
    func walletName(_ id: UUID?) -> String { ledger.wallets.first { $0.id == id }?.name ?? "—" }
    func backup() throws -> Data { let e = JSONEncoder(); e.outputFormatting = [.prettyPrinted, .sortedKeys]; return try e.encode(ledger) }
    func csv() -> String {
        func field(_ text: String) -> String {
            let safe = ["=", "+", "-", "@", "\t", "\r"].contains(where: { text.hasPrefix($0) }) ? "'" + text : text
            return "\"" + safe.replacingOccurrences(of: "\"", with: "\"\"") + "\""
        }
        let format = ISO8601DateFormatter()
        return "\u{FEFF}Ngày,Loại,Số tiền VND,Ví,Ví nhận,Danh mục,Ghi chú\r\n" + ledger.transactions.sorted { $0.date < $1.date }.map {
            [field(format.string(from: $0.date)), field($0.kind.title), String($0.amount), field(walletName($0.walletID)), field($0.destinationID == nil ? "" : walletName($0.destinationID)), field($0.category), field($0.note)].joined(separator: ",")
        }.joined(separator: "\r\n")
    }
}

struct ExportDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json, .commaSeparatedText] }
    var data: Data
    init(data: Data = Data()) { self.data = data }
    init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}

func money(_ value: Int64) -> String {
    let formatter = NumberFormatter(); formatter.locale = Locale(identifier: "vi_VN"); formatter.numberStyle = .currency; formatter.currencyCode = "VND"; formatter.maximumFractionDigits = 0
    return formatter.string(from: NSNumber(value: value)) ?? "\(value) ₫"
}
