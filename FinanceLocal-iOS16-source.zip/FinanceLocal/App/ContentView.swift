import SwiftUI
import UniformTypeIdentifiers

struct WalletEditor: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    var wallet: Wallet?
    @State private var name = ""
    @State private var balance = "0"
    @State private var error: String?
    var body: some View {
        NavigationStack {
            Form {
                TextField("Tên ví", text: $name)
                TextField("Số dư ban đầu VND", text: $balance).keyboardType(.numbersAndPunctuation)
                Text("Số dư ban đầu có thể âm. Thay đổi giá trị này sẽ điều chỉnh số dư hiện tại.").font(.caption).foregroundStyle(.secondary)
                if let error { Text(error).foregroundStyle(.red) }
            }.scrollContentBackground(.hidden).background(Palette.background).navigationTitle(wallet == nil ? "Thêm ví" : "Sửa ví").toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Hủy") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Lưu") {
                    let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !cleanName.isEmpty, let value = Int64(balance.trimmingCharacters(in: .whitespaces)) else { error = "Nhập tên ví và số dư nguyên hợp lệ."; return }
                    let next = Wallet(id: wallet?.id ?? UUID(), name: cleanName, openingBalance: value)
                    if store.update({ ledger in if let index = ledger.wallets.firstIndex(where: { $0.id == next.id }) { ledger.wallets[index] = next } else { ledger.wallets.append(next) } }) { dismiss() }
                }.disabled(!store.ready) }
            }.onAppear { if let wallet { name = wallet.name; balance = String(wallet.openingBalance) } }
        }
    }
}

struct BackupView: View {
    @EnvironmentObject var store: Store
    @State private var document = ExportDocument()
    @State private var type = UTType.json
    @State private var exporting = false
    @State private var importing = false
    @State private var pending: Data?
    @State private var confirming = false
    @State private var success = false
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 16) {
                        Image("Mascot").resizable().scaledToFit().frame(width: 64, height: 64).clipShape(RoundedRectangle(cornerRadius: 20))
                        VStack(alignment: .leading, spacing: 5) { Text("Nhím Money").font(.system(.title2, design: .rounded, weight: .bold)); Text("Từng chút một, ví đầy hơn.").font(.caption).foregroundStyle(.secondary) }
                    }.padding(.vertical, 8)
                }.listRowBackground(Palette.card)
                Section("Sao lưu") {
                    Button { export(json: true) } label: { Label("Xuất bản sao lưu JSON", systemImage: "square.and.arrow.up") }.disabled(!store.ready)
                    Button { export(json: false) } label: { Label("Xuất giao dịch CSV", systemImage: "tablecells") }.disabled(!store.ready)
                    Button { importing = true } label: { Label("Khôi phục từ JSON", systemImage: "square.and.arrow.down") }
                }
                Section("Dữ liệu trên thiết bị") {
                    LabeledContent("Số ví", value: String(store.ledger.wallets.count))
                    LabeledContent("Giao dịch", value: String(store.ledger.transactions.count))
                    Text("Không tài khoản, không quảng cáo, không gửi dữ liệu đến máy chủ. Bản sao lưu JSON và CSV chứa thông tin rõ; hãy lưu ở nơi riêng tư.")
                    Text("Xóa app có thể xóa toàn bộ dữ liệu. Hãy xuất JSON thường xuyên và trước khi cài lại.").foregroundStyle(.secondary)
                    if !store.ready { Text("Dữ liệu chưa tải được. Hãy khôi phục từ bản sao lưu; file gốc chưa bị ghi đè.").foregroundStyle(.red) }
                }
            }.scrollContentBackground(.hidden).background(Palette.background).navigationTitle("Cá nhân")
                .fileExporter(isPresented: $exporting, document: document, contentType: type, defaultFilename: "SoTien-\(Date().formatted(.iso8601.year().month().day().dateSeparator(.dash)))") { result in if case .failure(let error) = result { store.error = error.localizedDescription } }
                .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                    do {
                        let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
                        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                        guard size <= 25_000_000 else { throw LedgerError.invalid("File quá lớn.") }
                        let data = try Data(contentsOf: url)
                        try JSONDecoder().decode(Ledger.self, from: data).validate()
                        pending = data; confirming = true
                    } catch { store.error = error.localizedDescription }
                }
                .confirmationDialog("Thay thế dữ liệu hiện tại bằng bản sao lưu?", isPresented: $confirming, titleVisibility: .visible) {
                    Button("Khôi phục và thay thế", role: .destructive) { do { if let pending { try store.restore(pending); success = true } } catch { store.error = error.localizedDescription }; pending = nil }
                    Button("Hủy", role: .cancel) { pending = nil }
                } message: { Text("Nên xuất JSON hiện tại trước khi tiếp tục. Dữ liệu cũ cũng được lưu nội bộ trước khi thay thế.") }
                .alert("Đã khôi phục", isPresented: $success) { Button("Đóng", role: .cancel) {} }
        }
    }
    private func export(json: Bool) {
        do {
            type = json ? .json : .commaSeparatedText
            let data = json ? try store.backup() : Data(store.csv().utf8)
            document = ExportDocument(data: data); exporting = true
        }
        catch { store.error = error.localizedDescription }
    }
}
