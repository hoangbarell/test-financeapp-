import SwiftUI
import Charts
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject var store: Store
    var body: some View {
        TabView {
            DashboardView().tabItem { Label("Tổng quan", systemImage: "chart.pie.fill") }
            HistoryView().tabItem { Label("Giao dịch", systemImage: "list.bullet.rectangle") }
            WalletsView().tabItem { Label("Ví", systemImage: "wallet.pass.fill") }
            BackupView().tabItem { Label("Dữ liệu", systemImage: "externaldrive.fill") }
        }
    }
}

struct DashboardView: View {
    @EnvironmentObject var store: Store
    @State private var month = Date()
    @State private var adding = false
    private var interval: DateInterval { Calendar.current.dateInterval(of: .month, for: month)! }
    private var categories: [(name: String, amount: Int64)] {
        let entries = store.ledger.transactions.filter { $0.kind == .expense && $0.date >= interval.start && $0.date < interval.end }
        return Dictionary(grouping: entries, by: \.category).map { (name: $0.key, amount: $0.value.reduce(Int64(0)) { $0 + $1.amount }) }.sorted { $0.amount > $1.amount }
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("TỔNG TÀI SẢN TRONG VÍ").font(.caption).tracking(1.5)
                        Text(money(store.ledger.wallets.reduce(0) { $0 + store.ledger.balance($1.id) })).font(.system(.largeTitle, design: .rounded, weight: .bold)).minimumScaleFactor(0.5).lineLimit(1)
                        Text("Dữ liệu của bạn • Lưu trên thiết bị").font(.caption)
                    }.foregroundStyle(.white).padding(24).frame(maxWidth: .infinity, alignment: .leading).background(Color.teal.gradient, in: RoundedRectangle(cornerRadius: 24))
                    HStack {
                        Button { moveMonth(-1) } label: { Image(systemName: "chevron.left") }.accessibilityLabel("Tháng trước")
                        Spacer(); Text(month.formatted(.dateTime.month(.wide).year())).font(.headline); Spacer()
                        Button { moveMonth(1) } label: { Image(systemName: "chevron.right") }.accessibilityLabel("Tháng sau")
                    }
                    HStack(spacing: 12) {
                        metric("Thu nhập", amount: store.ledger.total(.income, in: interval), color: .teal)
                        metric("Chi tiêu", amount: store.ledger.total(.expense, in: interval), color: .orange)
                    }
                    Text("Chênh lệch: \(money(store.ledger.total(.income, in: interval) - store.ledger.total(.expense, in: interval)))").font(.subheadline)
                    Text("Chi tiêu theo danh mục").font(.title3.bold())
                    if categories.isEmpty {
                        Label("Chưa có chi tiêu trong tháng này", systemImage: "leaf").foregroundStyle(.secondary).padding(.vertical, 24)
                    } else {
                        Chart(categories, id: \.name) { item in
                            BarMark(x: .value("Số tiền", item.amount), y: .value("Danh mục", item.name)).foregroundStyle(Color.teal)
                        }.frame(height: CGFloat(max(160, categories.count * 36)))
                        ForEach(categories, id: \.name) { item in HStack { Text(item.name); Spacer(); Text(money(item.amount)).monospacedDigit() } }
                    }
                    Button { adding = true } label: { Label("Ghi giao dịch", systemImage: "plus.circle.fill").frame(maxWidth: .infinity).padding(10) }.buttonStyle(.borderedProminent).disabled(!store.ready || store.ledger.wallets.isEmpty)
                }.padding(20)
            }.navigationTitle("Sổ tiền của tôi")
                .sheet(isPresented: $adding) { EntryEditor() }
        }
    }
    private func moveMonth(_ count: Int) { month = Calendar.current.date(byAdding: .month, value: count, to: month) ?? month }
    private func metric(_ title: String, amount: Int64, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 8) { Text(title).font(.caption).foregroundStyle(.secondary); Text(money(amount)).font(.headline).foregroundStyle(color).minimumScaleFactor(0.5).lineLimit(1) }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
    }
}

struct HistoryView: View {
    @EnvironmentObject var store: Store
    @State private var search = ""
    @State private var kind: EntryKind?
    @State private var walletID: UUID?
    @State private var from = Calendar.current.dateInterval(of: .month, for: Date())!.start
    @State private var through = Date()
    @State private var adding = false
    @State private var editing: Transaction?
    @State private var deleting: Transaction?
    private var entries: [Transaction] {
        let end = Calendar.current.date(byAdding: .day, value: 1, to: Calendar.current.startOfDay(for: through))!
        return store.ledger.transactions.filter { entry in
            (kind == nil || entry.kind == kind) && (walletID == nil || entry.walletID == walletID || entry.destinationID == walletID) && entry.date >= Calendar.current.startOfDay(for: from) && entry.date < end && (search.isEmpty || "\(entry.note) \(entry.category) \(store.walletName(entry.walletID))".localizedCaseInsensitiveContains(search))
        }.sorted { $0.date > $1.date }
    }
    var body: some View {
        NavigationStack {
            List {
                Section("Bộ lọc") {
                    Picker("Loại", selection: $kind) { Text("Tất cả").tag(Optional<EntryKind>.none); ForEach(EntryKind.allCases) { Text($0.title).tag(Optional($0)) } }
                    Picker("Ví", selection: $walletID) { Text("Tất cả").tag(Optional<UUID>.none); ForEach(store.ledger.wallets) { Text($0.name).tag(Optional($0.id)) } }
                    DatePicker("Từ", selection: $from, displayedComponents: .date)
                    DatePicker("Đến", selection: $through, in: from..., displayedComponents: .date)
                }
                Section("\(entries.count) giao dịch") {
                    if entries.isEmpty { Text("Chưa có giao dịch phù hợp.").foregroundStyle(.secondary) }
                    ForEach(entries) { entry in
                        Button { editing = entry } label: {
                            HStack(alignment: .top, spacing: 12) {
                                Image(systemName: entry.kind == .income ? "arrow.down.left.circle.fill" : entry.kind == .expense ? "arrow.up.right.circle.fill" : "arrow.left.arrow.right.circle.fill").font(.title2).foregroundStyle(entry.kind == .expense ? Color.orange : Color.teal)
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(entry.kind == .transfer ? "Chuyển ví" : entry.category).font(.headline).foregroundStyle(.primary)
                                    Text(store.walletName(entry.walletID) + (entry.kind == .transfer ? " → " + store.walletName(entry.destinationID) : "")).font(.caption)
                                    if !entry.note.isEmpty { Text(entry.note).font(.caption).lineLimit(2) }
                                    Text(entry.date.formatted(date: .abbreviated, time: .omitted)).font(.caption2)
                                }.foregroundStyle(.secondary)
                                Spacer()
                                Text((entry.kind == .income ? "+" : entry.kind == .expense ? "−" : "") + money(entry.amount)).font(.subheadline.bold()).foregroundStyle(.primary)
                            }.padding(.vertical, 4)
                        }.swipeActions { Button("Xóa", role: .destructive) { deleting = entry } }
                    }
                }
            }.navigationTitle("Giao dịch").searchable(text: $search, prompt: "Ghi chú, danh mục, ví")
                .toolbar { Button { adding = true } label: { Image(systemName: "plus") }.disabled(!store.ready || store.ledger.wallets.isEmpty) }
                .sheet(isPresented: $adding) { EntryEditor() }
                .sheet(item: $editing) { EntryEditor(entry: $0) }
                .confirmationDialog("Xóa giao dịch này? Số dư ví sẽ được tính lại.", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
                    Button("Xóa giao dịch", role: .destructive) { if let id = deleting?.id { store.update { $0.transactions.removeAll { $0.id == id } } }; deleting = nil }
                }
        }
    }
}

struct EntryEditor: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    var entry: Transaction?
    @State private var kind = EntryKind.expense
    @State private var amount = ""
    @State private var walletID: UUID?
    @State private var destinationID: UUID?
    @State private var category = "Ăn uống"
    @State private var note = ""
    @State private var date = Date()
    @State private var error: String?
    var body: some View {
        NavigationStack {
            Form {
                Picker("Loại", selection: $kind) { ForEach(EntryKind.allCases) { Text($0.title).tag($0) } }
                TextField("Số tiền VND (ví dụ 45000)", text: $amount).keyboardType(.numberPad)
                Picker("Ví nguồn", selection: $walletID) { Text("Chọn ví").tag(Optional<UUID>.none); ForEach(store.ledger.wallets) { Text($0.name).tag(Optional($0.id)) } }
                if kind == .transfer {
                    Picker("Ví nhận", selection: $destinationID) { Text("Chọn ví").tag(Optional<UUID>.none); ForEach(store.ledger.wallets.filter { $0.id != walletID }) { Text($0.name).tag(Optional($0.id)) } }
                } else {
                    TextField("Danh mục", text: $category)
                    ScrollView(.horizontal, showsIndicators: false) { HStack { ForEach(kind == .expense ? ["Ăn uống", "Di chuyển", "Nhà ở", "Mua sắm", "Sức khỏe", "Giải trí", "Khác"] : ["Lương", "Thưởng", "Kinh doanh", "Khác"], id: \.self) { item in Button(item) { category = item }.buttonStyle(.bordered) } } }
                }
                DatePicker("Ngày", selection: $date, displayedComponents: [.date, .hourAndMinute])
                TextField("Ghi chú", text: $note, axis: .vertical).lineLimit(2...5)
                if let error { Text(error).foregroundStyle(.red) }
            }.navigationTitle(entry == nil ? "Ghi giao dịch" : "Sửa giao dịch")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Hủy") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) { Button("Lưu", action: save).disabled(!store.ready) }
                }.onAppear {
                    if let entry { kind = entry.kind; amount = String(entry.amount); walletID = entry.walletID; destinationID = entry.destinationID; category = entry.category; note = entry.note; date = entry.date }
                    else { walletID = store.ledger.wallets.first?.id }
                }
        }
    }
    private func save() {
        guard let value = Int64(amount.trimmingCharacters(in: .whitespaces)), value > 0, let walletID else { error = "Nhập số tiền nguyên dương và chọn ví."; return }
        let label = category.trimmingCharacters(in: .whitespacesAndNewlines)
        guard kind == .transfer || !label.isEmpty else { error = "Nhập danh mục."; return }
        let next = Transaction(id: entry?.id ?? UUID(), kind: kind, amount: value, walletID: walletID, destinationID: kind == .transfer ? destinationID : nil, category: kind == .transfer ? "Chuyển ví" : label, note: note, date: date)
        if store.update({ ledger in if let index = ledger.transactions.firstIndex(where: { $0.id == next.id }) { ledger.transactions[index] = next } else { ledger.transactions.append(next) } }) { dismiss() }
    }
}

struct WalletsView: View {
    @EnvironmentObject var store: Store
    @State private var adding = false
    @State private var editing: Wallet?
    @State private var deleting: Wallet?
    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach(store.ledger.wallets) { wallet in
                        Button { editing = wallet } label: { HStack { Label(wallet.name, systemImage: "wallet.pass"); Spacer(); Text(money(store.ledger.balance(wallet.id))).fontWeight(.semibold) }.foregroundStyle(.primary) }
                            .swipeActions { Button("Xóa", role: .destructive) { deleting = wallet } }
                    }
                } footer: { Text("Số dư = số dư ban đầu + thu − chi ± chuyển ví. Chỉ có thể xóa ví chưa có giao dịch.") }
            }.navigationTitle("Ví của tôi").toolbar { Button { adding = true } label: { Image(systemName: "plus") }.disabled(!store.ready) }
                .sheet(isPresented: $adding) { WalletEditor() }
                .sheet(item: $editing) { WalletEditor(wallet: $0) }
                .confirmationDialog("Xóa ví này?", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
                    Button("Xóa ví", role: .destructive) {
                        if let wallet = deleting {
                            if store.ledger.transactions.contains(where: { $0.walletID == wallet.id || $0.destinationID == wallet.id }) { store.error = "Ví đang có giao dịch. Hãy chuyển hoặc xóa các giao dịch trước." }
                            else { store.update { $0.wallets.removeAll { $0.id == wallet.id } } }
                        }; deleting = nil
                    }
                }
        }
    }
}

struct WalletEditor: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    var wallet: Wallet?
    @State private var name = ""
    @State private var balance = "0"
    @State private var error: String?
    var body: some View {
        NavigationStack {
            Form {
                TextField("Tên ví", text: $name)
                TextField("Số dư ban đầu VND", text: $balance).keyboardType(.numbersAndPunctuation)
                Text("Số dư ban đầu có thể âm. Thay đổi giá trị này sẽ điều chỉnh số dư hiện tại.").font(.caption).foregroundStyle(.secondary)
                if let error { Text(error).foregroundStyle(.red) }
            }.navigationTitle(wallet == nil ? "Thêm ví" : "Sửa ví").toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Hủy") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Lưu") {
                    let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !cleanName.isEmpty, let value = Int64(balance.trimmingCharacters(in: .whitespaces)) else { error = "Nhập tên ví và số dư nguyên hợp lệ."; return }
                    let next = Wallet(id: wallet?.id ?? UUID(), name: cleanName, openingBalance: value)
                    if store.update({ ledger in if let index = ledger.wallets.firstIndex(where: { $0.id == next.id }) { ledger.wallets[index] = next } else { ledger.wallets.append(next) } }) { dismiss() }
                }.disabled(!store.ready) }
            }.onAppear { if let wallet { name = wallet.name; balance = String(wallet.openingBalance) } }
        }
    }
}

struct BackupView: View {
    @EnvironmentObject var store: Store
    @State private var document = ExportDocument()
    @State private var type = UTType.json
    @State private var exporting = false
    @State private var importing = false
    @State private var pending: Data?
    @State private var confirming = false
    @State private var success = false
    var body: some View {
        NavigationStack {
            Form {
                Section("Sao lưu") {
                    Button { export(json: true) } label: { Label("Xuất bản sao lưu JSON", systemImage: "square.and.arrow.up") }.disabled(!store.ready)
                    Button { export(json: false) } label: { Label("Xuất giao dịch CSV", systemImage: "tablecells") }.disabled(!store.ready)
                    Button { importing = true } label: { Label("Khôi phục từ JSON", systemImage: "square.and.arrow.down") }
                }
                Section("Dữ liệu trên thiết bị") {
                    LabeledContent("Số ví", value: String(store.ledger.wallets.count))
                    LabeledContent("Giao dịch", value: String(store.ledger.transactions.count))
                    Text("Không tài khoản, không quảng cáo, không gửi dữ liệu đến máy chủ. Bản sao lưu JSON và CSV chứa thông tin rõ; hãy lưu ở nơi riêng tư.")
                    Text("Xóa app có thể xóa toàn bộ dữ liệu. Hãy xuất JSON thường xuyên và trước khi cài lại.").foregroundStyle(.secondary)
                    if !store.ready { Text("Dữ liệu chưa tải được. Hãy khôi phục từ bản sao lưu; file gốc chưa bị ghi đè.").foregroundStyle(.red) }
                }
            }.navigationTitle("Dữ liệu")
                .fileExporter(isPresented: $exporting, document: document, contentType: type, defaultFilename: "SoTien-\(Date().formatted(.iso8601.year().month().day().dateSeparator(.dash)))") { result in if case .failure(let error) = result { store.error = error.localizedDescription } }
                .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                    do {
                        let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
                        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                        guard size <= 25_000_000 else { throw LedgerError.invalid("File quá lớn.") }
                        let data = try Data(contentsOf: url)
                        try JSONDecoder().decode(Ledger.self, from: data).validate()
                        pending = data; confirming = true
                    } catch { store.error = error.localizedDescription }
                }
                .confirmationDialog("Thay thế dữ liệu hiện tại bằng bản sao lưu?", isPresented: $confirming, titleVisibility: .visible) {
                    Button("Khôi phục và thay thế", role: .destructive) { do { if let pending { try store.restore(pending); success = true } } catch { store.error = error.localizedDescription }; pending = nil }
                    Button("Hủy", role: .cancel) { pending = nil }
                } message: { Text("Nên xuất JSON hiện tại trước khi tiếp tục. Dữ liệu cũ cũng được lưu nội bộ trước khi thay thế.") }
                .alert("Đã khôi phục", isPresented: $success) { Button("Đóng", role: .cancel) {} }
        }
    }
    private func export(json: Bool) {
        do {
            type = json ? .json : .commaSeparatedText
            let data = json ? try store.backup() : Data(store.csv().utf8)
            document = ExportDocument(data: data); exporting = true
        }
        catch { store.error = error.localizedDescription }
    }
}
