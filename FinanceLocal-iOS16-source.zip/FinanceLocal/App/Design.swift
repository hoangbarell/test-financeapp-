import SwiftUI

enum Palette {
    static let accent = Color(red: 0.06, green: 0.43, blue: 0.36)
    static let mint = Color(red: 0.78, green: 0.94, blue: 0.87)
    static let background = Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? UIColor(red: 0.055, green: 0.09, blue: 0.085, alpha: 1) : UIColor(red: 0.96, green: 0.975, blue: 0.965, alpha: 1) })
    static let card = Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? UIColor(red: 0.10, green: 0.15, blue: 0.135, alpha: 1) : .white })
    static let ink = Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? UIColor(red: 0.90, green: 0.96, blue: 0.92, alpha: 1) : UIColor(red: 0.10, green: 0.20, blue: 0.17, alpha: 1) })
    static let positive = Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? UIColor(red: 0.40, green: 0.85, blue: 0.66, alpha: 1) : UIColor(red: 0.06, green: 0.43, blue: 0.36, alpha: 1) })
    static let negative = Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? UIColor(red: 1, green: 0.64, blue: 0.52, alpha: 1) : UIColor(red: 0.72, green: 0.28, blue: 0.17, alpha: 1) })
    static let colors: [Color] = [.init(red: 0.21, green: 0.63, blue: 0.51), .init(red: 0.96, green: 0.68, blue: 0.40), .init(red: 0.48, green: 0.58, blue: 0.85), .init(red: 0.77, green: 0.52, blue: 0.66), .init(red: 0.65, green: 0.72, blue: 0.40), .init(red: 0.43, green: 0.68, blue: 0.76)]
    static func symbol(_ category: String) -> String {
        switch category {
        case "Ăn uống": return "fork.knife"
        case "Di chuyển": return "car.fill"
        case "Nhà ở": return "house.fill"
        case "Mua sắm": return "bag.fill"
        case "Sức khỏe": return "heart.fill"
        case "Giải trí": return "gamecontroller.fill"
        case "Lương", "Thưởng", "Kinh doanh": return "banknote.fill"
        case "Chuyển ví": return "arrow.left.arrow.right"
        default: return "square.grid.2x2.fill"
        }
    }
}

struct Card<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content.padding(20).frame(maxWidth: .infinity, alignment: .leading)
            .background(Palette.card, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(Palette.ink.opacity(0.04), lineWidth: 1))
    }
}

struct CategoryIcon: View {
    let name: String
    var color: Color = Palette.positive
    var body: some View {
        Image(systemName: Palette.symbol(name)).font(.system(size: 17, weight: .semibold))
            .foregroundStyle(color).frame(width: 44, height: 44)
            .background(color.opacity(0.12), in: RoundedRectangle(cornerRadius: 15))
            .accessibilityHidden(true)
    }
}

struct AddButton: View {
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: "plus").font(.system(size: 24, weight: .medium)).foregroundStyle(.white)
                .frame(width: 60, height: 60).background(Palette.accent, in: Circle())
                .shadow(color: Palette.accent.opacity(0.25), radius: 12, y: 5)
        }.accessibilityLabel("Thêm giao dịch").padding(.trailing, 22).padding(.bottom, 14)
    }
}

struct SectionHeading: View {
    let title: String
    var subtitle: String? = nil
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.system(.title3, design: .rounded, weight: .bold)).foregroundStyle(Palette.ink)
            if let subtitle { Text(subtitle).font(.caption).foregroundStyle(.secondary) }
        }
    }
}

struct EmptyCard: View {
    let title: String
    let message: String
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "leaf.fill").font(.system(size: 28)).foregroundStyle(Palette.positive).padding(18).background(Palette.positive.opacity(0.1), in: Circle())
            Text(title).font(.headline).foregroundStyle(Palette.ink)
            Text(message).font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }.frame(maxWidth: .infinity).padding(.vertical, 25)
    }
}

struct ContentView: View {
    var body: some View {
        TabView {
            DashboardView().tabItem { Label("Tổng quan", systemImage: "square.grid.2x2") }
            HistoryView().tabItem { Label("Giao dịch", systemImage: "arrow.left.arrow.right") }
            WalletsView().tabItem { Label("Ví của tôi", systemImage: "wallet.pass") }
            BackupView().tabItem { Label("Cá nhân", systemImage: "person.crop.circle") }
        }.tint(Palette.positive)
            .preferredColorScheme(ProcessInfo.processInfo.arguments.contains("--preview-dark") ? .dark : nil)
    }
}

struct SpendingSlice: Identifiable {
    let name: String
    let amount: Int64
    let color: Color
    var id: String { name }
}

struct RingSegment: Shape {
    let start: Double
    let end: Double
    func path(in rect: CGRect) -> Path {
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = min(rect.width, rect.height) / 2
        let gap = min(0.005, (end - start) / 4)
        var path = Path()
        path.addArc(center: center, radius: radius - 14, startAngle: .degrees((start + gap) * 360 - 90), endAngle: .degrees((end - gap) * 360 - 90), clockwise: false)
        return path
    }
}

struct SpendingRing: View {
    let slices: [SpendingSlice]
    let total: Int64
    private func start(_ index: Int) -> Double { Double(slices.prefix(index).reduce(Int64(0)) { $0 + $1.amount }) / Double(max(total, 1)) }
    var body: some View {
        ZStack {
            Circle().stroke(Palette.ink.opacity(0.06), lineWidth: 24).padding(14)
            ForEach(Array(slices.enumerated()), id: \.element.id) { index, slice in
                RingSegment(start: start(index), end: start(index) + Double(slice.amount) / Double(max(total, 1)))
                    .stroke(slice.color, style: StrokeStyle(lineWidth: 24, lineCap: .butt))
            }
            VStack(spacing: 6) {
                Text("Tổng chi tiêu").font(.caption).foregroundStyle(.secondary)
                Text(money(total)).font(.system(.title3, design: .rounded, weight: .bold)).foregroundStyle(Palette.ink).minimumScaleFactor(0.5).lineLimit(1)
            }.padding(42)
        }.frame(width: 220, height: 220).accessibilityElement(children: .ignore).accessibilityLabel("Tổng chi tiêu \(money(total))")
    }
}

struct DashboardView: View {
    @EnvironmentObject var store: Store
    @State private var month = Date()
    @State private var adding = false
    private var interval: DateInterval { Calendar.current.dateInterval(of: .month, for: month)! }
    private var income: Int64 { store.ledger.total(.income, in: interval) }
    private var expense: Int64 { store.ledger.total(.expense, in: interval) }
    private var slices: [SpendingSlice] {
        let entries = store.ledger.transactions.filter { $0.kind == .expense && $0.date >= interval.start && $0.date < interval.end }
        var totals: [String: Int64] = [:]
        for entry in entries {
            totals[entry.category, default: 0] += entry.amount
        }
        var values: [(name: String, amount: Int64)] = []
        for (name, amount) in totals {
            values.append((name: name, amount: amount))
        }
        values.sort { left, right in
            if left.amount == right.amount { return left.name < right.name }
            return left.amount > right.amount
        }
        return values.enumerated().map { SpendingSlice(name: $0.element.name, amount: $0.element.amount, color: Palette.colors[$0.offset % Palette.colors.count]) }
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    header
                    balanceCard
                    HStack {
                        Button { move(-1) } label: { Image(systemName: "chevron.left").frame(width: 44, height: 44) }.accessibilityLabel("Tháng trước")
                        Spacer(); Text(month.formatted(.dateTime.month(.wide).year())).font(.subheadline.weight(.semibold)); Spacer()
                        Button { move(1) } label: { Image(systemName: "chevron.right").frame(width: 44, height: 44) }.accessibilityLabel("Tháng sau")
                    }.foregroundStyle(Palette.ink)
                    HStack(spacing: 12) { metric("Thu nhập", income, "arrow.down.left", Palette.positive); metric("Chi tiêu", expense, "arrow.up.right", Palette.negative) }
                    monthlySummary
                    spendingCard
                    if !store.ledger.transactions.isEmpty {
                        SectionHeading(title: "Gần đây", subtitle: "Những giao dịch mới nhất")
                        Card { VStack(spacing: 16) { ForEach(Array(store.ledger.transactions.sorted { $0.date > $1.date }.prefix(3))) { entry in TransactionRow(entry: entry) } } }
                    }
                }.padding(20).padding(.bottom, 80)
            }.background(Palette.background).toolbar(.hidden, for: .navigationBar)
                .overlay(alignment: .bottomTrailing) { AddButton { adding = true }.disabled(!store.ready || store.ledger.wallets.isEmpty) }
                .sheet(isPresented: $adding) { EntryEditor() }
                .onAppear { if ProcessInfo.processInfo.arguments.contains("--preview-editor") { adding = true } }
        }
    }
    private var header: some View {
HStack(spacing: 12) {
                        Image("Mascot").resizable().scaledToFill().frame(width: 48, height: 48).clipShape(RoundedRectangle(cornerRadius: 17)).accessibilityHidden(true)
                        VStack(alignment: .leading, spacing: 3) { Text("Chào bạn 👋").font(.subheadline).foregroundStyle(.secondary); Text("Nhím Money").font(.system(.title2, design: .rounded, weight: .bold)).foregroundStyle(Palette.ink) }
                        Spacer()
                        Image(systemName: "lock.shield").font(.title3).foregroundStyle(Palette.positive).accessibilityLabel("Dữ liệu lưu trên thiết bị")
                    }
    }
    private var monthlySummary: some View {
Card {
                        HStack { Image(systemName: "chart.line.uptrend.xyaxis").foregroundStyle(Palette.positive); Text("Chênh lệch tháng").font(.subheadline); Spacer(); Text(money(income - expense)).font(.subheadline.bold()).foregroundStyle(income >= expense ? Palette.positive : Palette.negative).minimumScaleFactor(0.5).lineLimit(1) }
                    }
    }
    private var spendingCard: some View {
Card {
                        VStack(alignment: .leading, spacing: 20) {
                            SectionHeading(title: "Tiền đã đi đâu?", subtitle: "Chi tiêu theo danh mục trong tháng")
                            if slices.isEmpty { EmptyCard(title: "Một khởi đầu mới", message: "Ghi giao dịch đầu tiên để nhìn rõ\ndòng tiền của bạn.") }
                            else {
                                HStack { Spacer(); SpendingRing(slices: slices, total: expense); Spacer() }
                                ForEach(slices) { slice in
                                    HStack(spacing: 12) {
                                        CategoryIcon(name: slice.name, color: slice.color)
                                        VStack(alignment: .leading, spacing: 6) {
                                            HStack { Text(slice.name).font(.subheadline.weight(.medium)); Spacer(); Text(money(slice.amount)).font(.subheadline.weight(.semibold)).lineLimit(1).minimumScaleFactor(0.5) }
                                            GeometryReader { geometry in Capsule().fill(slice.color.opacity(0.12)).overlay(alignment: .leading) { Capsule().fill(slice.color).frame(width: max(4, geometry.size.width * Double(slice.amount) / Double(max(expense, 1)))) } }.frame(height: 5)
                                        }
                                        Text("\(Int(Double(slice.amount) / Double(max(expense, 1)) * 100))%").font(.caption).foregroundStyle(.secondary).frame(width: 32, alignment: .trailing)
                                    }
                                }
                            }
                        }
                    }
    }
    private var balanceCard: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack { Label("Tổng số dư", systemImage: "wallet.pass").font(.subheadline.weight(.medium)); Spacer(); Text("VND").font(.caption.bold()).padding(.horizontal, 10).padding(.vertical, 6).background(.white.opacity(0.45), in: Capsule()) }
            Text(money(store.ledger.wallets.reduce(0) { $0 + store.ledger.balance($1.id) })).font(.system(size: 36, weight: .bold, design: .rounded)).lineLimit(1).minimumScaleFactor(0.5)
            HStack(spacing: 5) { Circle().fill(Palette.accent).frame(width: 5, height: 5); Text("\(store.ledger.wallets.count) ví · Dòng tiền trong tầm tay").font(.caption) }
        }.foregroundStyle(Color(red: 0.08, green: 0.25, blue: 0.20)).padding(24).frame(maxWidth: .infinity, alignment: .leading)
            .background(LinearGradient(colors: [Palette.mint, Color(red: 0.88, green: 0.97, blue: 0.86)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 28))
    }
    private func metric(_ title: String, _ amount: Int64, _ icon: String, _ color: Color) -> some View {
        Card { VStack(alignment: .leading, spacing: 12) {
            Image(systemName: icon).font(.system(size: 15, weight: .bold)).foregroundStyle(color).frame(width: 32, height: 32).background(color.opacity(0.1), in: Circle())
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(money(amount)).font(.system(.headline, design: .rounded)).foregroundStyle(Palette.ink).lineLimit(1).minimumScaleFactor(0.5)
        } }
    }
    private func move(_ value: Int) { month = Calendar.current.date(byAdding: .month, value: value, to: month) ?? month }
}

struct TransactionRow: View {
    @EnvironmentObject var store: Store
    let entry: Transaction
    var body: some View {
        HStack(spacing: 12) {
            CategoryIcon(name: entry.kind == .transfer ? "Chuyển ví" : entry.category, color: entry.kind == .expense ? Palette.negative : Palette.positive)
            VStack(alignment: .leading, spacing: 5) {
                Text(entry.kind == .transfer ? "Chuyển ví" : entry.category).font(.subheadline.weight(.semibold)).foregroundStyle(Palette.ink)
                Text(entry.note.isEmpty ? store.walletName(entry.walletID) : entry.note).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                if entry.kind == .transfer { Text("\(store.walletName(entry.walletID)) → \(store.walletName(entry.destinationID))").font(.caption2).foregroundStyle(.secondary).lineLimit(1) }
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 5) {
                Text((entry.kind == .income ? "+" : entry.kind == .expense ? "−" : "") + money(entry.amount)).font(.system(.subheadline, design: .rounded, weight: .semibold)).foregroundStyle(entry.kind == .expense ? Palette.negative : Palette.positive).lineLimit(1).minimumScaleFactor(0.6)
                Text(entry.date.formatted(.dateTime.hour().minute())).font(.caption2).foregroundStyle(.secondary)
            }
        }.padding(.vertical, 3)
    }
}

struct HistoryView: View {
    @EnvironmentObject var store: Store
    @State private var search = ""
    @State private var kind: EntryKind?
    @State private var walletID: UUID?
    @State private var from = Calendar.current.dateInterval(of: .month, for: Date())!.start
    @State private var through = Date()
    @State private var filters = false
    @State private var adding = false
    @State private var editing: Transaction?
    @State private var deleting: Transaction?
    private var entries: [Transaction] {
        let end = Calendar.current.date(byAdding: .day, value: 1, to: Calendar.current.startOfDay(for: through))!
        return store.ledger.transactions.filter { entry in
            (kind == nil || entry.kind == kind) && (walletID == nil || entry.walletID == walletID || entry.destinationID == walletID) && entry.date >= Calendar.current.startOfDay(for: from) && entry.date < end && (search.isEmpty || "\(entry.note) \(entry.category) \(store.walletName(entry.walletID))".localizedCaseInsensitiveContains(search))
        }.sorted { $0.date > $1.date }
    }
    private var days: [Date] { Array(Set(entries.map { Calendar.current.startOfDay(for: $0.date) })).sorted(by: >) }
    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack { Text("\(entries.count) giao dịch").font(.subheadline).foregroundStyle(.secondary); Spacer(); Button { filters = true } label: { Label("Bộ lọc", systemImage: "slider.horizontal.3").font(.subheadline.weight(.semibold)) } }
                    Text("\(from.formatted(date: .abbreviated, time: .omitted)) – \(through.formatted(date: .abbreviated, time: .omitted))").font(.caption).foregroundStyle(.secondary)
                }.listRowBackground(Color.clear).listRowSeparator(.hidden)
                if entries.isEmpty { EmptyCard(title: "Chưa có giao dịch", message: "Thêm thu chi hoặc thử đổi bộ lọc.").listRowBackground(Palette.card).listRowSeparator(.hidden) }
                ForEach(days, id: \.self) { day in
                    Section {
                        ForEach(entries.filter { Calendar.current.isDate($0.date, inSameDayAs: day) }) { entry in
                            Button { editing = entry } label: { TransactionRow(entry: entry) }.buttonStyle(.plain)
                                .swipeActions { Button("Xóa", role: .destructive) { deleting = entry } }.listRowBackground(Palette.card)
                        }
                    } header: { Text(day.formatted(.dateTime.weekday(.wide).day().month())).font(.caption.weight(.semibold)).textCase(nil) }
                }
                Color.clear.frame(height: 65).listRowBackground(Color.clear).listRowSeparator(.hidden)
            }.listStyle(.insetGrouped).scrollContentBackground(.hidden).background(Palette.background)
                .navigationTitle("Giao dịch").searchable(text: $search, prompt: "Tìm ghi chú, danh mục, ví")
                .overlay(alignment: .bottomTrailing) { AddButton { adding = true }.disabled(!store.ready || store.ledger.wallets.isEmpty) }
                .sheet(isPresented: $adding) { EntryEditor() }.sheet(item: $editing) { EntryEditor(entry: $0) }
                .sheet(isPresented: $filters) { NavigationStack { Form {
                    Picker("Loại", selection: $kind) { Text("Tất cả").tag(Optional<EntryKind>.none); ForEach(EntryKind.allCases) { Text($0.title).tag(Optional($0)) } }
                    Picker("Ví", selection: $walletID) { Text("Tất cả").tag(Optional<UUID>.none); ForEach(store.ledger.wallets) { Text($0.name).tag(Optional($0.id)) } }
                    DatePicker("Từ", selection: $from, displayedComponents: .date).onChange(of: from) { if through < $0 { through = $0 } }
                    DatePicker("Đến", selection: $through, in: from..., displayedComponents: .date)
                }.navigationTitle("Bộ lọc").toolbar { Button("Xong") { filters = false } } }.presentationDetents([.medium, .large]) }
                .confirmationDialog("Xóa giao dịch này?", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
                    Button("Xóa giao dịch", role: .destructive) { if let id = deleting?.id { store.update { $0.transactions.removeAll { $0.id == id } } }; deleting = nil }
                }
        }
    }
}

struct EntryEditor: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    var entry: Transaction?
    @State private var kind = EntryKind.expense
    @State private var amount = ""
    @State private var walletID: UUID?
    @State private var destinationID: UUID?
    @State private var category = "Ăn uống"
    @State private var note = ""
    @State private var date = Date()
    @State private var error: String?
    @FocusState private var amountFocused: Bool
    private var categories: [String] { kind == .expense ? ["Ăn uống", "Di chuyển", "Nhà ở", "Mua sắm", "Sức khỏe", "Giải trí", "Khác"] : ["Lương", "Thưởng", "Kinh doanh", "Khác"] }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 22) {
                    Picker("Loại", selection: $kind) { ForEach(EntryKind.allCases) { Text($0.title).tag($0) } }.pickerStyle(.segmented)
                    VStack(spacing: 10) {
                        Text("SỐ TIỀN · VND").font(.caption.weight(.semibold)).tracking(1.5).foregroundStyle(.secondary)
                        TextField("0", text: $amount).font(.system(size: 44, weight: .bold, design: .rounded)).multilineTextAlignment(.center).keyboardType(.numberPad).foregroundStyle(Palette.ink).focused($amountFocused).accessibilityLabel("Số tiền VND")
                    }.padding(.vertical, 12)
                    Card { VStack(spacing: 14) {
                        Picker(selection: $walletID) { Text("Chọn ví").tag(Optional<UUID>.none); ForEach(store.ledger.wallets) { Text($0.name).tag(Optional($0.id)) } } label: { Label(kind == .transfer ? "Từ ví" : "Ví thanh toán", systemImage: "wallet.pass") }
                        if kind == .transfer {
                            Divider()
                            Picker(selection: $destinationID) { Text("Chọn ví").tag(Optional<UUID>.none); ForEach(store.ledger.wallets.filter { $0.id != walletID }) { Text($0.name).tag(Optional($0.id)) } } label: { Label("Đến ví", systemImage: "arrow.down.forward") }
                        }
                        Divider()
                        DatePicker("Ngày", selection: $date, displayedComponents: [.date, .hourAndMinute]).font(.subheadline)
                    } }
                    if kind != .transfer {
                        VStack(alignment: .leading, spacing: 14) {
                            SectionHeading(title: "Chọn danh mục")
                            LazyVGrid(columns: [GridItem(.adaptive(minimum: 76))], spacing: 12) {
                                ForEach(categories, id: \.self) { name in
                                    Button { category = name } label: {
                                        VStack(spacing: 9) { CategoryIcon(name: name, color: category == name ? Palette.positive : .secondary); Text(name).font(.caption.weight(.medium)).foregroundStyle(Palette.ink).lineLimit(1).minimumScaleFactor(0.7) }
                                            .frame(maxWidth: .infinity).padding(.vertical, 12).background(category == name ? Palette.positive.opacity(0.08) : Palette.card, in: RoundedRectangle(cornerRadius: 18))
                                            .overlay(RoundedRectangle(cornerRadius: 18).stroke(category == name ? Palette.positive : .clear, lineWidth: 1.5))
                                    }.buttonStyle(.plain).accessibilityAddTraits(category == name ? .isSelected : [])
                                }
                            }
                            Card { TextField("Hoặc nhập danh mục riêng", text: $category).font(.subheadline) }
                        }
                    }
                    Card { HStack(alignment: .top) { Image(systemName: "square.and.pencil").foregroundStyle(.secondary); TextField("Thêm ghi chú…", text: $note, axis: .vertical).lineLimit(2...4).font(.subheadline) } }
                    if let error { Text(error).font(.subheadline).foregroundStyle(Palette.negative) }
                    Button(action: save) { Text(entry == nil ? "Lưu giao dịch" : "Lưu thay đổi").font(.headline).frame(maxWidth: .infinity).padding(18).foregroundStyle(.white).background(Palette.accent, in: RoundedRectangle(cornerRadius: 18)) }.disabled(!store.ready)
                }.padding(20)
            }.background(Palette.background).scrollDismissesKeyboard(.interactively)
                .navigationTitle(entry == nil ? "Ghi giao dịch" : "Sửa giao dịch").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button { dismiss() } label: { Image(systemName: "xmark").font(.subheadline.weight(.semibold)) }.accessibilityLabel("Đóng") }
                    ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Xong") { amountFocused = false } }
                }.onAppear {
                    if let entry { kind = entry.kind; amount = String(entry.amount); walletID = entry.walletID; destinationID = entry.destinationID; category = entry.category; note = entry.note; date = entry.date }
                    else { walletID = store.ledger.wallets.first?.id }
                }.onChange(of: kind) { value in
                    if entry == nil { category = value == .income ? "Lương" : "Ăn uống" }
                }
        }
    }
    private func save() {
        guard let value = Int64(amount.trimmingCharacters(in: .whitespaces)), value > 0, let walletID else { error = "Nhập số tiền nguyên dương và chọn ví."; return }
        let label = category.trimmingCharacters(in: .whitespacesAndNewlines)
        guard kind == .transfer || !label.isEmpty else { error = "Nhập danh mục."; return }
        let next = Transaction(id: entry?.id ?? UUID(), kind: kind, amount: value, walletID: walletID, destinationID: kind == .transfer ? destinationID : nil, category: kind == .transfer ? "Chuyển ví" : label, note: note, date: date)
        if store.update({ ledger in if let index = ledger.transactions.firstIndex(where: { $0.id == next.id }) { ledger.transactions[index] = next } else { ledger.transactions.append(next) } }) { dismiss() }
    }
}

struct WalletsView: View {
    @EnvironmentObject var store: Store
    @State private var adding = false
    @State private var editing: Wallet?
    @State private var deleting: Wallet?
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    SectionHeading(title: "Mỗi ví, một mục đích", subtitle: "Tiền mặt, ngân hàng và mọi khoản của bạn.")
                    ForEach(Array(store.ledger.wallets.enumerated()), id: \.element.id) { index, wallet in
                        Button { editing = wallet } label: {
                            Card { VStack(alignment: .leading, spacing: 22) {
                                HStack { CategoryIcon(name: "Chuyển ví", color: Palette.colors[index % Palette.colors.count]); Text(wallet.name).font(.headline).foregroundStyle(Palette.ink); Spacer(); Image(systemName: "ellipsis").foregroundStyle(.secondary) }
                                VStack(alignment: .leading, spacing: 5) { Text("SỐ DƯ HIỆN TẠI").font(.caption2.weight(.semibold)).tracking(1).foregroundStyle(.secondary); Text(money(store.ledger.balance(wallet.id))).font(.system(.title, design: .rounded, weight: .bold)).foregroundStyle(Palette.ink).minimumScaleFactor(0.5).lineLimit(1) }
                            } }
                        }.buttonStyle(.plain).contextMenu { Button("Sửa ví") { editing = wallet }; Button("Xóa ví", role: .destructive) { deleting = wallet } }
                    }
                    Button { adding = true } label: { Label("Thêm ví mới", systemImage: "plus").font(.headline).frame(maxWidth: .infinity).padding(22).foregroundStyle(Palette.positive).background(Palette.positive.opacity(0.08), in: RoundedRectangle(cornerRadius: 22)) }.disabled(!store.ready)
                    Text("Nhấn vào ví để chỉnh sửa. Nhấn giữ để xóa ví chưa có giao dịch.").font(.caption).foregroundStyle(.secondary).padding(.horizontal, 4)
                }.padding(20)
            }.background(Palette.background).navigationTitle("Ví của tôi")
                .sheet(isPresented: $adding) { WalletEditor() }.sheet(item: $editing) { WalletEditor(wallet: $0) }
                .confirmationDialog("Xóa ví này?", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
                    Button("Xóa ví", role: .destructive) {
                        if let wallet = deleting {
                            if store.ledger.transactions.contains(where: { $0.walletID == wallet.id || $0.destinationID == wallet.id }) { store.error = "Ví đang có giao dịch. Hãy chuyển hoặc xóa các giao dịch trước." }
                            else { store.update { $0.wallets.removeAll { $0.id == wallet.id } } }
                        }; deleting = nil
                    }
                }
        }
    }
}
