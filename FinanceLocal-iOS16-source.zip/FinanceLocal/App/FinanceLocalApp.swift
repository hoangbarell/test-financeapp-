import SwiftUI

@main struct FinanceLocalApp: App {
    @StateObject private var store = Store()
    var body: some Scene {
        WindowGroup {
            AppGate().environmentObject(store).tint(Palette.positive)
                .alert("Thông báo", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
                    Button("Đóng", role: .cancel) { store.error = nil }
                } message: { Text(store.error ?? "") }
        }
    }
}
