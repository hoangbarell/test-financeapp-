import SwiftUI
import LocalAuthentication
import UserNotifications
import PhotosUI
import Vision

struct PressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduced
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.opacity(configuration.isPressed ? 0.75 : 1)
            .scaleEffect(configuration.isPressed && !reduced ? 0.97 : 1)
            .animation(reduced ? nil : .easeOut(duration: 0.12), value: configuration.isPressed)
    }
}
struct MoneyText: View {
    let amount: Int64
    @AppStorage("hideBalances") private var hidden = false
    var body: some View { Text(hidden ? "••••••" : money(amount)).monospacedDigit() }
}
struct AppGate: View {
    @EnvironmentObject var store: Store
    @Environment(\.scenePhase) private var phase
    @AppStorage("appLock") private var enabled = false
    @State private var unlocked = false
    @State private var authenticating = false
    @State private var message = ""
    var body: some View {
        ZStack {
            if !enabled || unlocked { PreviewOrApp() }
            else {
                VStack(spacing: 22) {
                    Image("Mascot").resizable().scaledToFit().frame(width: 130, height: 130).clipShape(RoundedRectangle(cornerRadius: 32))
                    Text("Nhím giữ ví giúp bạn").font(.title2.bold())
                    Button("Mở khóa") { authenticate() }.buttonStyle(.borderedProminent).disabled(authenticating)
                    Text(message).font(.caption).foregroundStyle(.secondary)
                }.frame(maxWidth: .infinity, maxHeight: .infinity).background(Palette.background)
            }
            if phase != .active { Palette.background.ignoresSafeArea() }
        }.onChange(of: phase) { value in
            if value == .background { unlocked = false }
            if value == .active && enabled && !unlocked { authenticate() }
        }.onChange(of: enabled) { value in if !value { unlocked = false } }
            .onAppear { if enabled { authenticate() } }
    }
    private func authenticate() {
        guard !authenticating else { return }; authenticating = true
        LAContext().evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Mở dữ liệu Nhím Money") { success, error in
            DispatchQueue.main.async { unlocked = success; authenticating = false; message = success ? "" : (error?.localizedDescription ?? "Hãy thử lại.") }
        }
    }
}

struct PreviewOrApp: View {
    var body: some View {
        #if targetEnvironment(simulator)
        let args = ProcessInfo.processInfo.arguments
        if args.contains("--preview-calendar") { NavigationStack { CalendarLedgerView() } }
        else if args.contains("--preview-budgets") { NavigationStack { BudgetsView() } }
        else if args.contains("--preview-plans") { NavigationStack { PlansView() } }
        else if args.contains("--preview-quick") { NavigationStack { QuickEntryView() } }
        else { ContentView() }
        #else
        ContentView()
        #endif
    }
}

struct PlanningView: View {
    @EnvironmentObject var store: Store
    var body: some View {
        NavigationStack {
            List {
                Section {
                    NavigationLink { QuickEntryView() } label: { Label("Nhập nhanh & mẫu", systemImage: "sparkles") }
                    NavigationLink { CalendarLedgerView() } label: { Label("Lịch thu chi", systemImage: "calendar") }
                    NavigationLink { InsightsView() } label: { Label("Thống kê cùng kỳ", systemImage: "chart.bar.xaxis") }
                }
                Section("Lập kế hoạch") {
                    NavigationLink { BudgetsView() } label: { Label("Ngân sách tháng", systemImage: "chart.pie") }
                    NavigationLink { PlansView() } label: { Label("Khoản đến hạn", systemImage: "clock.badge.checkmark") }
                    NavigationLink { GoalsView() } label: { Label("Mục tiêu tiết kiệm", systemImage: "flag.checkered") }
                }
                Section("Kiểm tra dòng tiền") {
                    NavigationLink { ReconcileView() } label: { Label("Đối chiếu số dư ví", systemImage: "checkmark.seal") }
                    NavigationLink { CSVImportView() } label: { Label("Nhập CSV có xem trước", systemImage: "tablecells") }
                }
            }.scrollContentBackground(.hidden).background(Palette.background).navigationTitle("Kế hoạch")
        }
    }
}

struct QuickEntryView: View {
    @EnvironmentObject var store: Store
    @State private var text = ""
    @State private var draft: Transaction?
    @State private var error: String?
    @State private var imageItem: PhotosPickerItem?
    @State private var scanning = false
    var body: some View {
        Form {
            Section("Viết tự nhiên, kiểm tra trước khi lưu") {
                TextField("cà phê 35k hoặc nhận lương 12tr", text: $text, axis: .vertical)
                Button("Tạo bản nháp") { parse() }.disabled(text.isEmpty || store.ledger.wallets.isEmpty)
                if let error { Text(error).foregroundStyle(Palette.negative) }
                Text("Gợi ý theo từ khóa trên thiết bị. Câu có nhiều số cần nhập thủ công.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Đọc hóa đơn trên thiết bị") {
                PhotosPicker(selection: $imageItem, matching: .images) { Label(scanning ? "Đang đọc…" : "Chọn ảnh hóa đơn", systemImage: "doc.text.viewfinder") }.disabled(scanning)
                Text("Nhận dạng chữ bằng Vision; chọn hoặc sửa số tiền rồi tạo bản nháp. Ảnh không được gửi lên máy chủ.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Mẫu thường dùng") {
                if store.ledger.templates.isEmpty { Text("Bật ‘Lưu làm mẫu’ khi ghi giao dịch để thêm tại đây.").font(.subheadline).foregroundStyle(.secondary) }
                ForEach(store.ledger.templates) { template in
                    Button { draft = template.draft() } label: {
                        HStack { CategoryIcon(name: template.category); Text(template.name); Spacer(); MoneyText(amount: template.amount) }
                    }.swipeActions { Button("Xóa", role: .destructive) { store.update { $0.templates.removeAll { $0.id == template.id } } } }
                }
            }
        }.navigationTitle("Nhập nhanh").scrollContentBackground(.hidden).background(Palette.background)
            .sheet(item: $draft) { EntryEditor(entry: $0) }
            .onChange(of: imageItem) { item in
                guard let item else { return }; scanning = true
                Task {
                    do {
                        guard let data = try await item.loadTransferable(type: Data.self), let image = UIImage(data: data)?.cgImage else { throw LedgerError.invalid("Không đọc được ảnh.") }
                        let result = try await Task.detached(priority: .userInitiated) { () -> String in
                            let request = VNRecognizeTextRequest(); request.recognitionLevel = .accurate; request.usesLanguageCorrection = false
                            try VNImageRequestHandler(cgImage: image).perform([request])
                            return (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
                        }.value
                        text = result; error = "Đã đọc chữ. Hãy giữ lại mô tả và đúng một số tiền trước khi tạo bản nháp."
                    } catch { self.error = error.localizedDescription }
                    scanning = false
                }
            }
    }
    private func parse() {
        do {
            let result = try QuickEntry.parse(text)
            guard let wallet = store.ledger.wallets.first else { return }
            let remembered = UserDefaults.standard.string(forKey: "lastWallet").flatMap(UUID.init(uuidString:))
            let id = store.ledger.wallets.first(where: { $0.id == remembered })?.id ?? wallet.id
            draft = Transaction(kind: result.kind, amount: result.amount, walletID: id, category: result.category, note: result.note); error = nil
        } catch { self.error = error.localizedDescription }
    }
}

struct BudgetsView: View {
    @EnvironmentObject var store: Store
    @State private var name = ""
    @State private var amount = ""
    @State private var all = true
    @State private var error: String?
    private var interval: DateInterval { Calendar.current.dateInterval(of: .month, for: Date())! }
    var body: some View {
        List {
            Section("Lặp lại mỗi tháng · không cộng dồn") {
                ForEach(store.ledger.budgets) { budget in BudgetRow(budget: budget, interval: interval)
                    .swipeActions { Button("Xóa", role: .destructive) { store.update { $0.budgets.removeAll { $0.id == budget.id } } } }
                }
                if store.ledger.budgets.isEmpty { Text("Tạo hạn mức tổng hoặc từng danh mục.").foregroundStyle(.secondary) }
            }
            Section("Thêm hoặc cập nhật hạn mức") {
                Toggle("Toàn bộ chi tiêu", isOn: $all)
                if !all { TextField("Danh mục, ví dụ Ăn uống", text: $name) }
                TextField("Hạn mức VND, ví dụ 3tr", text: $amount).keyboardType(.numbersAndPunctuation)
                Button("Lưu ngân sách") { save() }
                if let error { Text(error).foregroundStyle(Palette.negative) }
                Text("Hạn mức tổng và danh mục được theo dõi riêng, không cộng chúng với nhau. Còn trong ngân sách không đồng nghĩa số dư có thể chi.").font(.caption).foregroundStyle(.secondary)
            }
        }.navigationTitle("Ngân sách").scrollContentBackground(.hidden).background(Palette.background)
    }
    private func save() {
        do {
            let value = try QuickEntry.amount(amount); let category = all ? nil : name.trimmingCharacters(in: .whitespacesAndNewlines)
            guard all || !(category ?? "").isEmpty else { throw LedgerError.invalid("Nhập danh mục.") }
            if store.update({ ledger in
                if let i = ledger.budgets.firstIndex(where: { $0.category == category }) { ledger.budgets[i].limit = value }
                else { ledger.budgets.append(Budget(name: all ? "Ngân sách tháng" : category!, limit: value, category: category)) }
            }) { amount = ""; error = nil }
        } catch { self.error = error.localizedDescription }
    }
}
struct BudgetRow: View {
    @EnvironmentObject var store: Store
    @Environment(\.accessibilityReduceMotion) private var reduced
    let budget: Budget
    let interval: DateInterval
    private var spent: Int64 { store.ledger.netExpense(in: interval, category: budget.category) }
    private var remaining: Int64 { budget.limit - spent }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack { Text(budget.name).font(.headline); Spacer(); Text(remaining < 0 ? "Vượt hạn mức" : spent >= budget.limit * 8 / 10 ? "Gần hạn mức" : "Trong hạn mức").font(.caption).foregroundStyle(remaining < 0 ? Palette.negative : Palette.positive) }
            ProgressView(value: min(1, max(0, Double(spent) / Double(budget.limit)))).tint(remaining < 0 ? Palette.negative : Palette.positive)
                .animation(reduced ? nil : .easeInOut(duration: 0.25), value: spent)
            HStack { MoneyText(amount: spent); Text("/"); MoneyText(amount: budget.limit) }.font(.caption).foregroundStyle(.secondary)
            HStack { Text(remaining < 0 ? "Vượt" : "Còn"); MoneyText(amount: abs(remaining)) }.font(.subheadline.weight(.semibold))
        }.padding(.vertical, 8)
    }
}

struct CalendarLedgerView: View {
    @EnvironmentObject var store: Store
    @State private var month = Date()
    @State private var selected = Date()
    private let calendar = Calendar.current
    private var start: Date { calendar.dateInterval(of: .month, for: month)!.start }
    private var days: [Date] { (0..<(calendar.range(of: .day, in: .month, for: month)?.count ?? 0)).compactMap { calendar.date(byAdding: .day, value: $0, to: start) } }
    private var offset: Int { (calendar.component(.weekday, from: start) - calendar.firstWeekday + 7) % 7 }
    private var entries: [Transaction] { store.ledger.transactions.filter { calendar.isDate($0.date, inSameDayAs: selected) }.sorted { $0.date > $1.date } }
    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                HStack {
                    Button { move(-1) } label: { Image(systemName: "chevron.left").frame(width: 44, height: 44) }.accessibilityLabel("Tháng trước")
                    Spacer(); Text(month.formatted(.dateTime.month(.wide).year())).font(.headline); Spacer()
                    Button { move(1) } label: { Image(systemName: "chevron.right").frame(width: 44, height: 44) }.accessibilityLabel("Tháng sau")
                }
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 2), count: 7), spacing: 8) {
                    ForEach(0..<7, id: \.self) { i in Text(calendar.shortStandaloneWeekdaySymbols[(calendar.firstWeekday - 1 + i) % 7]).font(.caption2).foregroundStyle(.secondary) }
                    ForEach(0..<offset, id: \.self) { _ in Color.clear.frame(height: 50) }
                    ForEach(days, id: \.self) { day in dayCell(day) }
                }
                Card {
                    VStack(alignment: .leading, spacing: 14) {
                        Text(selected.formatted(date: .complete, time: .omitted)).font(.headline)
                        if entries.isEmpty { Text("Không có giao dịch trong ngày.").foregroundStyle(.secondary) }
                        ForEach(entries) { entry in TransactionRow(entry: entry) }
                    }
                }
            }.padding(16)
        }.background(Palette.background).navigationTitle("Lịch thu chi").navigationBarTitleDisplayMode(.inline)
    }
    private func dayCell(_ day: Date) -> some View {
        let interval = calendar.dateInterval(of: .day, for: day)!
        let spent = store.ledger.netExpense(in: interval)
        let income = store.ledger.total(.income, in: interval)
        return Button { selected = day } label: {
            VStack(spacing: 4) {
                Text("\(calendar.component(.day, from: day))").font(.subheadline.weight(.semibold))
                HStack(spacing: 3) { if spent != 0 { Circle().fill(Palette.negative).frame(width: 5, height: 5) }; if income > 0 { Circle().fill(Palette.positive).frame(width: 5, height: 5) } }.frame(height: 6)
            }.frame(maxWidth: .infinity, minHeight: 48).foregroundStyle(Palette.ink)
                .background(calendar.isDate(day, inSameDayAs: selected) ? Palette.mint : Palette.card, in: RoundedRectangle(cornerRadius: 12))
        }.buttonStyle(PressStyle()).accessibilityLabel("\(day.formatted(date: .complete, time: .omitted)), chi \(money(spent)), thu \(money(income))")
    }
    private func move(_ value: Int) { month = calendar.date(byAdding: .month, value: value, to: month)!; selected = calendar.dateInterval(of: .month, for: month)!.start }
}

struct InsightsView: View {
    @EnvironmentObject var store: Store
    private var current: DateInterval { Calendar.current.dateInterval(of: .month, for: Date())! }
    private var spent: Int64 { store.ledger.netExpense(in: DateInterval(start: current.start, end: Date())) }
    private var prior: DateInterval {
        let c = Calendar.current; let start = c.date(byAdding: .month, value: -1, to: current.start)!
        let days = c.dateComponents([.day], from: current.start, to: c.startOfDay(for: Date())).day ?? 0
        let endMonth = c.dateInterval(of: .month, for: start)!.end
        let sameDay = c.date(byAdding: .day, value: days, to: start)!
        let seconds = Date().timeIntervalSince(c.startOfDay(for: Date()))
        return DateInterval(start: start, end: min(endMonth, sameDay.addingTimeInterval(seconds)))
    }
    private var categories: [String] { Array(Set(store.ledger.transactions.filter { $0.kind == .expense && $0.date >= current.start && $0.date < current.end }.map(\.category))).sorted { store.ledger.netExpense(in: current, category: $0) > store.ledger.netExpense(in: current, category: $1) } }
    var body: some View {
        List {
            Section("Tháng này đến hiện tại") {
                metric("Chi ròng", spent)
                metric("Thu nhập", store.ledger.total(.income, in: DateInterval(start: current.start, end: Date())))
                metric("Chi/ngày đã qua", spent / Int64(max(1, Calendar.current.component(.day, from: Date()))))
            }
            Section("So với cùng kỳ tháng trước") {
                metric("Tháng trước đến cùng ngày", store.ledger.netExpense(in: prior))
                metric("Chênh lệch chi", spent - store.ledger.netExpense(in: prior))
                Text("So cùng số ngày, tháng ngắn dừng ở cuối tháng. Hoàn trả giảm chi ở ngày tiền về; điều chỉnh ví và chuyển ví không tính thu chi.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Danh mục chi nhiều nhất") {
                ForEach(categories, id: \.self) { category in HStack { CategoryIcon(name: category); Text(category); Spacer(); MoneyText(amount: store.ledger.netExpense(in: current, category: category)) } }
                if categories.isEmpty { Text("Chưa đủ dữ liệu.").foregroundStyle(.secondary) }
            }
        }.navigationTitle("Thống kê").scrollContentBackground(.hidden).background(Palette.background)
    }
    private func metric(_ title: String, _ amount: Int64) -> some View { HStack { Text(title); Spacer(); MoneyText(amount: amount).fontWeight(.semibold) } }
}

struct PlansView: View {
    @EnvironmentObject var store: Store
    @State private var adding = false
    @State private var confirming: PlannedEntry?
    private var plans: [PlannedEntry] { store.ledger.plans.filter(\.active).sorted { $0.nextDate < $1.nextDate } }
    var body: some View {
        List {
            Section {
                Text("Khoản dự kiến chưa ảnh hưởng số dư. Khi xác nhận, app ghi đúng một kỳ; kỳ tiếp theo sẽ xuất hiện sau đó.").font(.caption).foregroundStyle(.secondary)
                ForEach(plans) { p in
                    VStack(alignment: .leading, spacing: 10) {
                        HStack { Text(p.name).font(.headline); Spacer(); MoneyText(amount: p.amount) }
                        Text("\(p.nextDate.formatted(date: .abbreviated, time: .omitted)) · \(p.cadence.title) · \(store.walletName(p.walletID))").font(.caption).foregroundStyle(.secondary)
                        Button(p.kind == .income ? "Xác nhận đã nhận" : "Xác nhận đã trả") { confirming = p }.disabled(Calendar.current.startOfDay(for: p.nextDate) > Calendar.current.startOfDay(for: Date()))
                    }.padding(.vertical, 5).swipeActions { Button("Dừng", role: .destructive) { store.update { ledger in if let i = ledger.plans.firstIndex(where: { $0.id == p.id }) { ledger.plans[i].active = false } } } }
                }
                if plans.isEmpty { Text("Chưa có khoản đến hạn.").foregroundStyle(.secondary) }
            }
        }.navigationTitle("Khoản đến hạn").scrollContentBackground(.hidden).background(Palette.background)
            .toolbar { Button { adding = true } label: { Image(systemName: "plus") }.accessibilityLabel("Thêm khoản dự kiến") }
            .sheet(isPresented: $adding) { PlanEditor() }
            .confirmationDialog("Ghi nhận kỳ này vào ví?", isPresented: Binding(get: { confirming != nil }, set: { if !$0 { confirming = nil } }), titleVisibility: .visible) {
                Button("Xác nhận") { if let p = confirming { store.confirm(p) }; confirming = nil }
            }
    }
}
struct PlanEditor: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var amount = ""
    @State private var category = "Nhà ở"
    @State private var kind = EntryKind.expense
    @State private var wallet: UUID?
    @State private var date = Date()
    @State private var cadence = Cadence.monthly
    @State private var error: String?
    var body: some View {
        NavigationStack {
            Form {
                TextField("Tên khoản", text: $name)
                TextField("Số tiền VND", text: $amount).keyboardType(.numbersAndPunctuation)
                Picker("Loại", selection: $kind) { Text("Chi tiêu").tag(EntryKind.expense); Text("Thu nhập").tag(EntryKind.income) }
                TextField("Danh mục", text: $category)
                Picker("Ví", selection: $wallet) { ForEach(store.ledger.wallets) { Text($0.name).tag(Optional($0.id)) } }
                DatePicker("Kỳ đầu", selection: $date)
                Picker("Lặp", selection: $cadence) { ForEach(Cadence.allCases, id: \.self) { Text($0.title).tag($0) } }
                if let error { Text(error).foregroundStyle(.red) }
            }.navigationTitle("Khoản dự kiến").toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Hủy") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Lưu") { save() } }
            }.onAppear { wallet = store.ledger.wallets.first?.id }
        }
    }
    private func save() {
        do { guard !name.trimmingCharacters(in: .whitespaces).isEmpty, !category.isEmpty, let wallet else { throw LedgerError.invalid("Nhập tên, danh mục và chọn ví.") }
            let p = PlannedEntry(name: name, kind: kind, amount: try QuickEntry.amount(amount), walletID: wallet, category: category, nextDate: date, cadence: cadence)
            if store.update({ $0.plans.append(p) }) { dismiss() }
        } catch { self.error = error.localizedDescription }
    }
}

struct GoalsView: View {
    @EnvironmentObject var store: Store
    @State private var editing: SavingGoal?
    @State private var adding = false
    var body: some View {
        List {
            Section {
                Text("Tiến độ do bạn cập nhật; đây là kế hoạch, không tạo hoặc trừ tiền trong ví.").font(.caption).foregroundStyle(.secondary)
                ForEach(store.ledger.goals) { goal in
                    Button { editing = goal } label: {
                        VStack(alignment: .leading, spacing: 10) {
                            Text(goal.name).font(.headline)
                            ProgressView(value: min(1, Double(goal.saved) / Double(goal.target)))
                            HStack { MoneyText(amount: goal.saved); Text("/"); MoneyText(amount: goal.target) }.font(.caption)
                            Text("Đến \(goal.date.formatted(date: .abbreviated, time: .omitted))").font(.caption).foregroundStyle(.secondary)
                            HStack { Text("Cần dành/tháng:"); MoneyText(amount: needed(goal)) }.font(.subheadline)
                        }.padding(.vertical, 8)
                    }.swipeActions { Button("Xóa", role: .destructive) { store.update { $0.goals.removeAll { $0.id == goal.id } } } }
                }
            }
        }.navigationTitle("Tiết kiệm").scrollContentBackground(.hidden).background(Palette.background)
            .toolbar { Button { adding = true } label: { Image(systemName: "plus") }.accessibilityLabel("Thêm mục tiêu") }
            .sheet(isPresented: $adding) { GoalEditor() }.sheet(item: $editing) { GoalEditor(goal: $0) }
    }
    private func needed(_ goal: SavingGoal) -> Int64 {
        let months = max(1, (Calendar.current.dateComponents([.month], from: Date(), to: goal.date).month ?? 0) + 1)
        return Int64(ceil(Double(max(0, goal.target - goal.saved)) / Double(months)))
    }
}
struct GoalEditor: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) private var dismiss
    var goal: SavingGoal?
    @State private var name = ""
    @State private var target = ""
    @State private var saved = "0"
    @State private var date = Date()
    @State private var error: String?
    var body: some View {
        NavigationStack {
            Form {
                TextField("Tên mục tiêu", text: $name)
                TextField("Cần đạt VND", text: $target).keyboardType(.numbersAndPunctuation)
                TextField("Đã dành VND", text: $saved).keyboardType(.numbersAndPunctuation)
                DatePicker("Mục tiêu đến", selection: $date, displayedComponents: .date)
                if let error { Text(error).foregroundStyle(.red) }
            }.navigationTitle("Mục tiêu").toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Hủy") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Lưu") { save() } }
            }.onAppear { if let goal { name = goal.name; target = String(goal.target); saved = String(goal.saved); date = goal.date } }
        }
    }
    private func save() {
        do {
            var next = SavingGoal(name: name.trimmingCharacters(in: .whitespacesAndNewlines), target: try QuickEntry.amount(target), saved: saved == "0" ? 0 : try QuickEntry.amount(saved), date: date)
            next.id = goal?.id ?? next.id
            if store.update({ ledger in if let i = ledger.goals.firstIndex(where: { $0.id == next.id }) { ledger.goals[i] = next } else { ledger.goals.append(next) } }) { dismiss() }
        } catch { self.error = error.localizedDescription }
    }
}

struct ReconcileView: View {
    @EnvironmentObject var store: Store
    @State private var wallet: UUID?
    @State private var actual = ""
    @State private var reason = "Đối chiếu số dư thực tế"
    @State private var confirming = false
    @State private var difference: Int64?
    var body: some View {
        Form {
            Picker("Ví", selection: $wallet) { ForEach(store.ledger.wallets) { Text($0.name).tag(Optional($0.id)) } }
            if let wallet { HStack { Text("Theo sổ"); Spacer(); MoneyText(amount: store.ledger.balance(wallet)) } }
            TextField("Số dư thực tế VND (có thể âm)", text: $actual).keyboardType(.numbersAndPunctuation)
            TextField("Lý do điều chỉnh", text: $reason)
            Button("Kiểm tra chênh lệch") {
                guard let wallet, let value = Int64(actual), abs(value == Int64.min ? 0 : value) <= 1_000_000_000_000_000, value != Int64.min else { store.error = "Nhập số nguyên VND trong giới hạn."; return }
                difference = value - store.ledger.balance(wallet)
            }
            if let difference {
                HStack { Text("Chênh lệch"); Spacer(); MoneyText(amount: difference) }
                Text("Rà soát giao dịch thiếu/trùng trước. Điều chỉnh tạo bản ghi riêng, không tính thu nhập hay chi tiêu.").font(.caption).foregroundStyle(.secondary)
                Button("Tạo bản ghi điều chỉnh") { confirming = true }.disabled(difference == 0)
            }
        }.navigationTitle("Đối chiếu ví").onAppear { wallet = store.ledger.wallets.first?.id }
            .onChange(of: wallet) { _ in difference = nil }.onChange(of: actual) { _ in difference = nil }
            .confirmationDialog("Ghi điều chỉnh số dư?", isPresented: $confirming, titleVisibility: .visible) {
                Button("Xác nhận") {
                    if let wallet, let difference, !reason.trimmingCharacters(in: .whitespaces).isEmpty {
                        if store.update({ $0.transactions.append(Transaction(kind: .adjustment, amount: difference, walletID: wallet, category: "Điều chỉnh", note: reason)) }) { self.difference = nil; actual = "" }
                    } else { store.error = "Nhập lý do điều chỉnh." }
                }
            }
    }
}

struct TransactionTools: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) private var dismiss
    let entry: Transaction
    @State private var amount = ""
    @State private var category = "Khác"
    @State private var date = Date()
    var body: some View {
        NavigationStack {
            Form {
                Section("Khoản chi gốc") { Text(entry.category); MoneyText(amount: entry.amount) }
                Section("Ghi hoàn trả") {
                    TextField("Số tiền hoàn VND", text: $amount).keyboardType(.numbersAndPunctuation)
                    DatePicker("Ngày tiền về", selection: $date)
                    Button("Lưu hoàn trả") { refund() }
                    Text("Hoàn trả vào ví gốc, giảm chi danh mục ở ngày tiền về. Không tính thành thu nhập.").font(.caption).foregroundStyle(.secondary)
                }
                Section("Chia khoản chi thành hai phần") {
                    TextField("Danh mục phần thứ hai", text: $category)
                    Text("Dùng số tiền phía trên làm phần thứ hai; phần còn lại giữ danh mục gốc.").font(.caption).foregroundStyle(.secondary)
                    Button("Chia khoản chi") { split() }
                }
            }.navigationTitle("Hoàn trả / chia chi").toolbar { Button("Đóng") { dismiss() } }
        }
    }
    private func refund() {
        do {
            let value = try QuickEntry.amount(amount)
            let e = Transaction(kind: .refund, amount: value, walletID: entry.walletID, category: entry.category, note: "Hoàn trả: \(entry.note)", date: date, relatedID: entry.id)
            if store.update({ $0.transactions.append(e) }) { dismiss() }
        } catch { store.error = error.localizedDescription }
    }
    private func split() {
        do {
            guard !store.ledger.transactions.contains(where: { $0.kind == .refund && $0.relatedID == entry.id }) else { throw LedgerError.invalid("Khoản đã hoàn trả không thể chia. Hãy xử lý hoàn trả trước.") }
            let value = try QuickEntry.amount(amount)
            let parts = try entry.split([(category: entry.category, amount: entry.amount - value), (category: category, amount: value)])
            if store.update({ $0.transactions.removeAll { $0.id == entry.id }; $0.transactions.append(contentsOf: parts) }) { dismiss() }
        } catch { store.error = error.localizedDescription }
    }
}

struct PrivacySettings: View {
    @EnvironmentObject var store: Store
    @AppStorage("appLock") private var locked = false
    @AppStorage("hideBalances") private var hidden = false
    @AppStorage("billReminders") private var reminders = false
    @AppStorage("lastExport") private var lastExport = 0.0
    @State private var backup: URL?
    @State private var confirming = false
    var body: some View {
        Form {
            Section("Riêng tư") {
                Toggle("Khóa bằng Face ID / mã máy", isOn: Binding(get: { locked }, set: { value in authorizeLock(value) }))
                Toggle("Che số tiền", isOn: $hidden)
                Text("Khóa áp dụng khi app vào nền. File backup xuất ra vẫn là dữ liệu rõ.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Nhắc hạn") {
                Toggle("Thông báo khoản dự kiến", isOn: Binding(get: { reminders }, set: { value in
                    if value { UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { allowed, _ in DispatchQueue.main.async { reminders = allowed; store.scheduleReminders(); if !allowed { store.error = "Chưa được cấp thông báo. Bạn có thể bật trong Cài đặt iPhone." } } } }
                    else { reminders = false; UNUserNotificationCenter.current().removeAllPendingNotificationRequests() }
                }))
                Text("Thông báo chỉ nhắc kiểm tra; app không tự ghi hay thanh toán.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Bản sao lưu nội bộ · tối đa 20 bản") {
                Text(lastExport == 0 ? "Chưa ghi nhận xuất JSON. Hãy lưu một bản ra Files trước khi cài lại app." : "Lần xuất JSON: \(Date(timeIntervalSince1970: lastExport).formatted(date: .abbreviated, time: .shortened))").font(.caption)
                Text("Bản nội bộ tạo trước thay đổi đầu ngày và trước nhập CSV. Xóa app cũng xóa các bản này.").font(.caption).foregroundStyle(.secondary)
                ForEach(store.localBackups(), id: \.self) { url in Button(url.lastPathComponent) { backup = url; confirming = true }.font(.caption) }
            }
        }.navigationTitle("Riêng tư & sao lưu")
            .confirmationDialog("Khôi phục bản nội bộ và thay thế dữ liệu?", isPresented: $confirming, titleVisibility: .visible) {
                Button("Khôi phục", role: .destructive) { do { if let backup { try store.restore(Data(contentsOf: backup)) } } catch { store.error = error.localizedDescription } }
            }
    }
    private func authorizeLock(_ value: Bool) {
        let context = LAContext()
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: value ? "Bật khóa Nhím Money" : "Tắt khóa Nhím Money") { success, error in
            DispatchQueue.main.async { if success { locked = value } else { store.error = error?.localizedDescription ?? "Chưa xác thực được thiết bị." } }
        }
    }
}
