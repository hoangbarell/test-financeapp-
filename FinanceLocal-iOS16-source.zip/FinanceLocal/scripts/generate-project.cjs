const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const files = ['App/FinanceLocalApp.swift', 'App/Store.swift', 'App/ContentView.swift', 'App/Design.swift', 'Sources/LedgerCore/Ledger.swift', 'Sources/LedgerCore/Planning.swift', 'App/UpgradeViews.swift', 'App/CSVImportView.swift'];
const id = n => n.toString(16).toUpperCase().padStart(24, '0');
const fileRefs = files.map((file, i) => `${id(100+i)} = {isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = "${file}"; sourceTree = "<group>"; };`).join('\n');
const buildRefs = files.map((_, i) => `${id(200+i)} = {isa = PBXBuildFile; fileRef = ${id(100+i)}; };`).join('\n');
const settings = `CLANG_ENABLE_MODULES = YES; SDKROOT = iphoneos; IPHONEOS_DEPLOYMENT_TARGET = 16.0; SWIFT_VERSION = 5.0; TARGETED_DEVICE_FAMILY = "1,2"; PRODUCT_BUNDLE_IDENTIFIER = personal.finance.local; PRODUCT_NAME = "$(TARGET_NAME)"; GENERATE_INFOPLIST_FILE = YES; INFOPLIST_KEY_CFBundleDisplayName = "Nhím Money"; INFOPLIST_KEY_LSApplicationCategoryType = "public.app-category.finance"; INFOPLIST_KEY_UILaunchScreen_Generation = YES; INFOPLIST_KEY_UIApplicationSceneManifest_Generation = YES; INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents = YES; INFOPLIST_KEY_UISupportedInterfaceOrientations = "UIInterfaceOrientationPortrait UIInterfaceOrientationLandscapeLeft UIInterfaceOrientationLandscapeRight"; MARKETING_VERSION = 1.2; CURRENT_PROJECT_VERSION = 3; INFOPLIST_KEY_NSFaceIDUsageDescription = "Mở khóa dữ liệu Nhím Money bằng Face ID."; ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon; SWIFT_EMIT_LOC_STRINGS = YES; CODE_SIGN_STYLE = Automatic;`;
const project = `// !$*UTF8*$!
{ archiveVersion = 1; classes = {}; objectVersion = 56; objects = {
${fileRefs}
${buildRefs}
${id(110)} = {isa = PBXFileReference; lastKnownFileType = folder.assetcatalog; path = App/Assets.xcassets; sourceTree = "<group>"; };
${id(210)} = {isa = PBXBuildFile; fileRef = ${id(110)}; };
${id(1)} = {isa = PBXProject; attributes = {LastUpgradeCheck = 1600; }; buildConfigurationList = ${id(10)}; compatibilityVersion = "Xcode 14.0"; developmentRegion = vi; hasScannedForEncodings = 0; knownRegions = (vi, en, Base); mainGroup = ${id(2)}; productRefGroup = ${id(3)}; projectDirPath = ""; projectRoot = ""; targets = (${id(4)}); };
${id(2)} = {isa = PBXGroup; children = (${files.map((_, i) => id(100+i)).join(',')},${id(110)},${id(3)}); sourceTree = "<group>"; };
${id(3)} = {isa = PBXGroup; children = (${id(5)}); name = Products; sourceTree = "<group>"; };
${id(5)} = {isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = FinanceLocal.app; sourceTree = BUILT_PRODUCTS_DIR; };
${id(4)} = {isa = PBXNativeTarget; buildConfigurationList = ${id(11)}; buildPhases = (${id(6)},${id(7)},${id(8)}); buildRules = (); dependencies = (); name = FinanceLocal; productName = FinanceLocal; productReference = ${id(5)}; productType = "com.apple.product-type.application"; };
${id(6)} = {isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = (${files.map((_, i) => id(200+i)).join(',')}); runOnlyForDeploymentPostprocessing = 0; };
${id(7)} = {isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0; };
${id(8)} = {isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = (${id(210)}); runOnlyForDeploymentPostprocessing = 0; };
${id(10)} = {isa = XCConfigurationList; buildConfigurations = (${id(12)},${id(13)}); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release; };
${id(11)} = {isa = XCConfigurationList; buildConfigurations = (${id(14)},${id(15)}); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release; };
${id(12)} = {isa = XCBuildConfiguration; buildSettings = {SWIFT_OPTIMIZATION_LEVEL = "-Onone"; DEBUG_INFORMATION_FORMAT = dwarf; }; name = Debug; };
${id(13)} = {isa = XCBuildConfiguration; buildSettings = {SWIFT_COMPILATION_MODE = wholemodule; SWIFT_OPTIMIZATION_LEVEL = "-O"; DEBUG_INFORMATION_FORMAT = "dwarf-with-dsym"; }; name = Release; };
${id(14)} = {isa = XCBuildConfiguration; buildSettings = {${settings} SWIFT_ACTIVE_COMPILATION_CONDITIONS = DEBUG; }; name = Debug; };
${id(15)} = {isa = XCBuildConfiguration; buildSettings = {${settings}}; name = Release; };
}; rootObject = ${id(1)}; }
`;
const output = path.join(root, 'FinanceLocal.xcodeproj');
fs.mkdirSync(path.join(output, 'xcshareddata/xcschemes'), {recursive:true});
fs.writeFileSync(path.join(output, 'project.pbxproj'), project);
fs.writeFileSync(path.join(output, 'xcshareddata/xcschemes/FinanceLocal.xcscheme'), `<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3"><BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="${id(4)}" BuildableName="FinanceLocal.app" BlueprintName="FinanceLocal" ReferencedContainer="container:FinanceLocal.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction><LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="${id(4)}" BuildableName="FinanceLocal.app" BlueprintName="FinanceLocal" ReferencedContainer="container:FinanceLocal.xcodeproj"/></BuildableProductRunnable></LaunchAction><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/></Scheme>`);
console.log('Generated FinanceLocal.xcodeproj (iOS 16.0).');
