#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "Requires macOS with full Xcode selected using xcode-select." >&2
  exit 1
fi
swift test
xcodebuild -project FinanceLocal.xcodeproj -scheme FinanceLocal -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
APP="build/DerivedData/Build/Products/Release-iphoneos/FinanceLocal.app"
test -d "$APP"
mkdir -p build/package/Payload
ditto "$APP" build/package/Payload/FinanceLocal.app
/usr/libexec/PlistBuddy -c 'Print :MinimumOSVersion' "$APP/Info.plist"
python3 - <<'PY'
from pathlib import Path
import zipfile
root = Path('build/package')
output = Path('build/FinanceLocal-unsigned.ipa')
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in (root / 'Payload').rglob('*'):
        if path.is_file():
            archive.write(path, path.relative_to(root))
print(output.resolve())
PY
echo "Unsigned IPA created. Sign it before installation."
