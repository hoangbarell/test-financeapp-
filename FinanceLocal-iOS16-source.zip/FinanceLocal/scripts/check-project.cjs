// Structural checks only; this does NOT compile or execute Swift.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const project = fs.readFileSync(path.join(root, 'FinanceLocal.xcodeproj/project.pbxproj'), 'utf8');
const ids = [...project.matchAll(/^([0-9A-F]{24}) = /gm)].map(match => match[1]);
assert.equal(new Set(ids).size, ids.length, 'Duplicate project IDs');
for (const reference of project.matchAll(/\b[0-9A-F]{24}\b/g)) assert(ids.includes(reference[0]), `Missing object ${reference[0]}`);
const sources = [...project.matchAll(/path = "([^"]+\.swift)"/g)].map(match => match[1]);
assert.equal(sources.length, 8);
for (const file of sources) assert(fs.existsSync(path.join(root, file)), `Missing source: ${file}`);
assert.equal((project.match(/IPHONEOS_DEPLOYMENT_TARGET = 16\.0/g) || []).length, 2);
const scheme = fs.readFileSync(path.join(root, 'FinanceLocal.xcodeproj/xcshareddata/xcschemes/FinanceLocal.xcscheme'), 'utf8');
assert(scheme.includes('BlueprintIdentifier="000000000000000000000004"'));
assert(fs.readFileSync(path.join(root, 'scripts/build-ipa.sh'), 'utf8').includes('CODE_SIGNING_ALLOWED=NO'));
console.log(`PASS: ${ids.length} project objects, ${sources.length} source files, Debug/Release iOS 16.0, shared scheme and unsigned build configuration.`);
console.log('Swift compile, unit tests and device UI verification still require macOS/Xcode.');
