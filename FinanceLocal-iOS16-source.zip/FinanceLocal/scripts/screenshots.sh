#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
xcodebuild -project FinanceLocal.xcodeproj -scheme FinanceLocal -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' -derivedDataPath build/Simulator CODE_SIGNING_ALLOWED=NO build
DEVICE=$(xcrun simctl list devices available --json | python3 -c 'import json,sys; data=json.load(sys.stdin); print(next(d["udid"] for devices in data["devices"].values() for d in devices if "iPhone" in d["name"]))')
xcrun simctl boot "$DEVICE" || true
xcrun simctl bootstatus "$DEVICE" -b
xcrun simctl status_bar "$DEVICE" override --time '9:41' --dataNetwork wifi --wifiMode active --wifiBars 3 --batteryState charged --batteryLevel 100
xcrun simctl install "$DEVICE" build/Simulator/Build/Products/Debug-iphonesimulator/FinanceLocal.app
mkdir -p build/previews
xcrun simctl launch "$DEVICE" personal.finance.local --preview-sample
sleep 4
xcrun simctl io "$DEVICE" screenshot build/previews/dashboard.png
xcrun simctl terminate "$DEVICE" personal.finance.local
xcrun simctl launch "$DEVICE" personal.finance.local --preview-sample --preview-editor
sleep 4
xcrun simctl io "$DEVICE" screenshot build/previews/editor.png
xcrun simctl terminate "$DEVICE" personal.finance.local
xcrun simctl launch "$DEVICE" personal.finance.local --preview-sample --preview-dark
sleep 4
xcrun simctl io "$DEVICE" screenshot build/previews/dark.png
