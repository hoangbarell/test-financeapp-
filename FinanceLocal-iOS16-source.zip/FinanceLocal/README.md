# Nhím Money — iOS 16+

Ứng dụng SwiftUI cá nhân, lưu dữ liệu offline bằng JSON trong Application Support. Không backend, subscription hoặc SDK theo dõi. Đồng tiền duy nhất của bản đầu là VND.

## Tính năng

- Ví với số dư ban đầu; thêm và sửa ví, xóa ví chưa có giao dịch.
- Thêm, sửa, xóa thu/chi/chuyển ví; chuyển ví không tính vào thu/chi.
- Tổng tài sản, tổng thu/chi theo tháng, biểu đồ vòng và thanh danh mục bằng SwiftUI.
- Tìm kiếm, lọc loại/ví/khoảng ngày.
- Xuất CSV UTF-8 cho Excel; xuất/khôi phục JSON đầy đủ.
- Ghi file nguyên tử với iOS file protection; chỉ cập nhật UI sau khi ghi thành công.
- Kiểm tra backup trước khi thay thế; lưu file cũ nội bộ trước restore.

## Build IPA chưa ký trên macOS

Cần máy Mac với Xcode đầy đủ và Command Line Tools được chọn. Project Xcode đã được tạo sẵn, không cần thư viện bên ngoài hay XcodeGen.

```bash
cd FinanceLocal
bash scripts/build-ipa.sh
```

Script chạy unit tests, build Release cho thiết bị iOS (minimum iOS 16.0), rồi đóng gói `build/FinanceLocal-unsigned.ipa`. File này chưa ký; người dùng tự ký và cài. Đây là gói build cho thiết bị, không phải simulator và không phải gói phân phối App Store.

Mở `FinanceLocal.xcodeproj` nếu muốn build bằng giao diện Xcode. Scheme: `FinanceLocal`. Chọn Team/Bundle ID riêng khi cần ký. Giữ Bundle ID ổn định khi cập nhật.

## Kiểm thử

```bash
swift test
xcodebuild -project FinanceLocal.xcodeproj -scheme FinanceLocal -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' CODE_SIGNING_ALLOWED=NO build
```

Các test kiểm tra chuyển ví, backup round-trip, ID trùng, phiên bản không hỗ trợ, số tiền không hợp lệ và tính lại số dư sau xóa giao dịch.

Kiểm tra thủ công trên iOS 16: tạo hai ví; thêm thu/chi; chuyển ví; sửa/xóa; mở lại app và kiểm tra số dư; xuất JSON rồi restore; thử JSON hỏng; dùng ở chế độ máy bay; cài đè cùng Bundle ID và xác minh giữ dữ liệu; kiểm tra VoiceOver, Dark Mode và cỡ chữ lớn. Chưa có Face ID lock, AI, bank sync, đa tiền tệ hoặc tự động backup ngoài thiết bị.

## Trạng thái bàn giao

Bản 1.1 (build 2) có giao diện mint, tên Nhím Money và icon nhím béo cầm tiền theo nét bút chì màu. Icon tạo bằng ImageGen rồi xuất thành bộ AppIcon iPhone/iPad. Bundle ID personal.finance.local và định dạng dữ liệu được giữ ổn định.

GitHub Actions run 38157903343 đã vượt qua 6 unit tests và build Release cho thiết bị, minimum iOS 16.0. Chưa kiểm thử trực tiếp trên iPhone iOS 16; người dùng tự ký và cài IPA.

## Dữ liệu

Số tiền lưu bằng Int64 theo đồng VND. Mọi số dư được suy ra từ giao dịch. JSON dùng UUID và Date theo Codable mặc định của Foundation; không chỉnh tay timestamp nếu không hiểu định dạng. CSV chỉ dành để xem, không dùng để restore. File xuất chứa dữ liệu rõ. Xóa app có thể làm mất dữ liệu; hãy xuất JSON trước khi cài lại. Không có khóa Face ID riêng trong bản này.

Project có thể tái tạo bằng `node scripts/generate-project.cjs` nếu đã cài Node.js; không cần bước này cho build thông thường.
